<?php

namespace App\Filament\Resources\TopicResource\Pages;

use App\Filament\Resources\TopicResource;
use App\Models\Axis;
use App\Models\ControlReport;
use App\Models\ControlReportFaculty;
use App\Models\Topic;
use App\Models\TopicAxis;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\Page;
use Filament\Support\Enums\Alignment;
use Filament\Tables;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;

class SubTopics extends Page implements HasTable
{
    use InteractsWithTable;

    protected static string $resource = TopicResource::class;

    protected static string $view = 'filament.resources.topic-resource.pages.sub-topics';

    public Topic $record;

    public function mount(Topic $record): void
    {
        $this->record = $record;
    }

    public function table(Table $table): Table
    {
        return $table
            ->query(fn(): Builder => Topic::query()->where('main_topic_id', $this->record->id))
            ->columns([
                Tables\Columns\TextColumn::make('#')
                    ->alignment(Alignment::Center)
                    ->rowIndex(),
                Tables\Columns\TextColumn::make('code')
                    ->alignment(Alignment::Center)
                    ->searchable()
                    ->translateLabel()
                    ->sortable(),
                Tables\Columns\ToggleColumn::make('is_active')
                    ->alignment(Alignment::Center)
                    ->label(__('Is Active'))
                    ->visible(fn() => auth()->user()->hasRole('Super Admin') || auth()->user()->hasRole('System Admin'))
                    ->afterStateUpdated(function () {
                        Notification::make()
                            ->success()
                            ->color('success')
                            ->title(__('Data_Updated_successfully'))
                            ->seconds(5)
                            ->send();
                    }),
                Tables\Columns\TextColumn::make('title')
                    ->alignment(Alignment::Center)
                    ->searchable()
                    ->translateLabel()
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->alignment(Alignment::Center)
                    ->dateTime()
                    ->translateLabel()
                    ->sortable()
                    ->searchable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->alignment(Alignment::Center)
                    ->dateTime()
                    ->translateLabel()
                    ->sortable()
                    ->searchable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->defaultSort('code', 'asc')
            ->filters([
                Tables\Filters\TernaryFilter::make('is_active')
                    ->label(__('Is Active'))
                    ->placeholder(__('All Topics'))
                    ->trueLabel(__('Active'))
                    ->falseLabel(__('Not Active'))
                    ->visible(fn() => auth()->user()->hasRole('Super Admin') || auth()->user()->hasRole('System Admin'))
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->url(fn(Topic $record): string => TopicResource::getUrl('edit', ['record' => $record->id])),
                Tables\Actions\DeleteAction::make()
                    ->before(function (Tables\Actions\DeleteAction $action, Topic $record) {
                        // Directly check if related data exists in topics_agendas table
                        $count = DB::table('topics_agendas')
                            ->where('topic_id', $record->id)
                            ->count();
                        $count2 = DB::table('topics')
                            ->where('main_topic_id', $record->id)
                            ->count();
                        // Check if $record exists and if there is related data
                        if ($record->exists && ($count > 0 || $count2 > 0)) {
                            Notification::make()
                                ->danger()
                                ->color('danger')
                                ->title(__('Failed to delete'))
                                ->body(__('Topic contains related data'))
                                ->seconds(10)
                                ->send();

                            // This will halt and cancel the delete action modal.
                            $action->cancel();
                        }
                    }),
                Tables\Actions\Action::make('Clone Data')
                    ->label(function ($record) {
                        return __('Clone');
                    })
                    ->color('warning')
                    ->icon('heroicon-o-play')
                    ->action(function ($record) {
                        $topic = Topic::find($record->id);
                        $existingReportData = ControlReport::where('topic_id', $record->id)->first();
                        $existingReportFacultyData = ControlReportFaculty::where('topic_id', $record->id)->first();

                        $titleSuffix = 'مكرر';

                        do {
                            // Generate a random number
                            $randomNumber = rand(1000, 9999); // You can adjust the range as needed

                            // Concatenate the title with the suffix and random number
                            $title = $topic->title . ' ' . $titleSuffix . ' ' . $randomNumber;

                            // Check if the title already exists in the database
                            $titleExists = Topic::where('title', $title)->exists();
                        } while ($titleExists);

                        $latestRecord = Topic::latest('id')->first();
                        $latestCode = $latestRecord->code ?? 'tpc_0';
                        $latestNumber = intval(preg_replace('/[^0-9]+/', '', $latestCode));
                        $newNumber = $latestNumber + 1;
                        $newCode = 'tpc_' . $newNumber;
                        $latestOrder = intval($latestRecord->order ?? '0');
                        $newOrder = $latestOrder + 1;

                        if (is_null($topic->main_topic_id)) {
                            $newTopic = new Topic();
                            $newTopic->title = $title;
                            $newTopic->code = $newCode;
                            $newTopic->order = $newOrder;
                            $newTopic->classification_reference = $topic->classification_reference;
                            $newTopic->save();
                        } else {
                            $formData = TopicAxis::where('topic_id', $record->id)->get('field_data'); // JSON string
                            $AxisId = TopicAxis::where('topic_id', $record->id)->first()->axis_id;
                            $mainTopicId = $topic->main_topic_id;

                            $newTopic = new Topic();
                            $newTopic->title = $title;
                            $newTopic->code = $newCode;
                            $newTopic->order = $newOrder;
                            $newTopic->main_topic_id = $mainTopicId;
                            $newTopic->classification_reference = $topic->classification_reference;
                            $newTopic->escalation_authority = $topic->escalation_authority;
                            $newTopic->decisions = $topic->decisions;
                            $newTopic->save();

                            if ($formData) {
                                $decodedFormData = json_decode($formData, true);
                                if (is_array($decodedFormData) && !empty($decodedFormData)) {
                                    foreach ($decodedFormData as $axisId => $content) {
                                        if (!empty($content)) {
                                            $axis = Axis::find($AxisId);
                                            if ($axis) {
                                                // Attach axis with JSON encoded field_data
                                                $newTopic->axes()->attach($AxisId, ['field_data' => $content['field_data']]);
                                            }
                                        }
                                    }
                                }
                            }



                            if ($existingReportData) {
                                ControlReport::create([
                                    'topic_id' => $newTopic->id,
                                    'content' => $existingReportData->content,
                                    'topic_formate' => $existingReportData->topic_formate
                                ]);
                            }
                            if ($existingReportFacultyData) {
                                ControlReportFaculty::create([
                                    'topic_id' => $newTopic->id,
                                    'content' => $existingReportFacultyData->content,
                                    'topic_formate' => $existingReportFacultyData->topic_formate

                                ]);
                            }
                        }

                        Notification::make()
                            ->success()
                            ->color('success')
                            ->title(__('Classify has been copied successfully'))
                            ->body(__('Classify title') . ' => ' . $title)
                            ->seconds(10)
                            ->send();
                    }),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make()
                ->url(fn(): string => TopicResource::getUrl('create')),
            Actions\Action::make('back')
                ->label(__('Back'))
                ->color('gray')
                ->url(fn(): string => TopicResource::getUrl('index')),
        ];
    }

    public function getTitle(): string
    {
        return __('Sub Topics');
    }

    public function getHeading(): string
    {
        return __('Sub Topics');
    }
}
