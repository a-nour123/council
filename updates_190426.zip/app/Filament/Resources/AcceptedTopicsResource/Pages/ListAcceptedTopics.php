<?php

namespace App\Filament\Resources\AcceptedTopicsResource\Pages;

use App\Filament\Resources\AcceptedTopicsResource;
use Filament\Resources\Pages\ListRecords;

class ListAcceptedTopics extends ListRecords
{
    protected static string $resource = AcceptedTopicsResource::class;

    protected function getHeaderActions(): array
    {
        return [
            //
        ];
    }
}
