<?php

namespace App\Filament\Resources\AcceptedTopicsResource\Pages;

use App\Filament\Resources\AcceptedTopicsResource;
use Filament\Resources\Pages\EditRecord;
use Filament\Notifications\Notification;

class EditAcceptedTopic extends EditRecord
{
    protected static string $resource = AcceptedTopicsResource::class;

    protected function getHeaderActions(): array
    {
        return [
            //
        ];
    }

    protected function getSavedNotification(): ?Notification
    {
        return Notification::make()
            ->success()
            ->title(__('Saved'))
            ->body(__('Topic updated successfully.'));
    }
}
