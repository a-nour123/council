<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AcceptedTopicsResource\Pages;
use App\Models\AgandesTopicForm;
use App\Models\TopicAgenda;
use App\Models\Topic;
use App\Models\Department;
use App\Models\Department_Council;
use App\Models\FacultyCouncil;
use App\Models\SessionTopic;
use App\Models\User;
use Filament\Facades\Filament;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Support\Enums\Alignment;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AcceptedTopicsResource extends Resource
{
    protected static ?string $model = TopicAgenda::class;

    protected static ?string $navigationIcon = 'heroicon-o-check-circle';
    protected static ?int $navigationSort = 7;
    protected static ?string $navigationGroup = 'Topics Management';
    public static function canViewAny(): bool
    {
        return auth()->user()->can('acceptedTopics', TopicAgenda::class);
    }
    public static function form(Form $form): Form
    {
        return $form
            ->schema([]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('#')
                    ->alignment(Alignment::Center)
                    ->label(__('Agenda Number'))
                    ->rowIndex(),
                Tables\Columns\TextColumn::make('topic.title')
                    ->alignment(Alignment::Center)
                    ->label(__('Agenda Type'))
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('')
                    ->alignment(Alignment::Center)
                    ->label(__('Title'))
                    ->getStateUsing(function ($record) {
                        // dd(self::initializeTopicsWithoutDecision($record->id));
                        return self::initializeTopicsWithoutDecision($record->id);
                    })
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('departement.faculty.' . self::getFacultyAndDepartmentName())
                    ->alignment(Alignment::Center)
                    ->label(__('Faculty'))
                    ->visible(auth()->user()->hasRole('Super Admin'))
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('departement.' . self::getFacultyAndDepartmentName())
                    ->alignment(Alignment::Center)
                    ->label(__('Department'))
                    ->visible(function () {
                        $userDepartmentsCount = Department_Council::where('user_id', auth()->id())->pluck('department_id')->count();
                        if (!auth()->user()->hasRole('Super Admin') && $userDepartmentsCount == 1)
                            return false;
                        else
                            return true;
                    })
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('owner.name')
                    ->alignment(Alignment::Center)
                    ->label(__('Created by'))
                    ->searchable()
                    // ->hidden(auth()->user()->position_id == 1) // hidden if user position is Acadmic Staff
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->alignment(Alignment::Center)
                    ->label(__('Agenda Date'))
                    ->dateTime()
                    ->sortable()
                    ->searchable(),
                // ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->alignment(Alignment::Center)
                    ->translateLabel()
                    ->dateTime()
                    ->sortable()
                    ->searchable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])

            ->filters([
                SelectFilter::make('department_id')
                    ->label(__('Department'))
                    ->options(function () {
                        if (auth()->user()->hasRole('Super Admin')) {
                            return Department::pluck(self::getFacultyAndDepartmentName(), 'id');
                        } else {
                            $userDepartments = Department_Council::where('department__councils.user_id', auth()->id())
                                ->join('departments', 'departments.id', '=', 'department__councils.department_id')
                                ->select(
                                    'departments.' . self::getFacultyAndDepartmentName() . ' as department_name',
                                    'departments.id as department_id',
                                );

                            return $userDepartments->pluck('department_name', 'department_id');
                        }
                    })
                    ->visible(function () {
                        $userDepartmentsCount = Department_Council::where('user_id', auth()->id())->pluck('department_id')->count();
                        if (!auth()->user()->hasRole('Super Admin') && $userDepartmentsCount == 1)
                            return false;
                        else
                            return true;
                    })
            ])

            ->actions([
                Tables\Actions\ActionGroup::make([
                    Tables\Actions\Action::make('reject')
                        ->label(__('Reject'))
                        ->color('danger')
                        ->icon('heroicon-o-x-circle')
                        ->requiresConfirmation()
                        ->form([
                            Forms\Components\Textarea::make('rejection_reason')
                                ->label(__('Rejection Reason'))
                                ->required()
                                ->maxLength(1000)
                                ->placeholder(__('Enter the reason for rejection')),
                        ])
                        ->action(function (TopicAgenda $record, array $data) {
                            $record->update([
                                'status' => 2,
                                'updates' => 2, // rejected from head_of_dep
                                'note' => $data['rejection_reason'],
                            ]);

                            Notification::make()
                                ->title(__('Topic Rejected'))
                                ->body(__('The topic has been successfully rejected.'))
                                ->success()
                                ->send();
                        }),

                    Tables\Actions\Action::make('pending')
                        ->label(__('Mark as Pending'))
                        ->color('warning')
                        ->icon('heroicon-o-clock')
                        ->requiresConfirmation()
                        ->action(function (TopicAgenda $record) {
                            $record->update([
                                'status' => 0,
                            ]);

                            Notification::make()
                                ->title(__('Topic Status Updated'))
                                ->body(__('The topic has been marked as pending.'))
                                ->warning()
                                ->send();
                        }),

                    Tables\Actions\ViewAction::make()
                        ->label(__('Details')),
                ]),
            ])
            ->recordUrl(function ($record) {
                return null;
            }) // disable opening edit mode when click on row
            ->defaultSort('created_at', 'desc')

            ->query(function (TopicAgenda $query) {

                $departmentCouncilId = DB::table('department__councils')
                    ->where('user_id', auth()->user()->id)
                    ->pluck('department_id')
                    ->toArray();

                if (auth()->user()->hasRole('Super Admin') || in_array(auth()->user()->position_id, [2])) {

                    // Step 1: Get agendas not yet added to any session
                    $AgendaIds = TopicAgenda::where('status', 1)
                        ->whereIn('department_id', $departmentCouncilId)
                        ->where('classification_reference', '!=', 3)
                        ->pluck('id');

                    $existingAgendaIds = SessionTopic::whereIn('topic_agenda_id', $AgendaIds)
                        ->pluck('topic_agenda_id')
                        ->toArray();

                    $filteredAgendaIds = $AgendaIds->diff($existingAgendaIds);

                    // Step 2: Get agendas returned from dean (status 2 or 3) that have updates
                    $returnedAgenda = DB::table('college_councils')
                        ->whereNotNull('college_councils.topic_id')
                        ->join('session_topics', 'college_councils.topic_id', '=', 'session_topics.topic_agenda_id')
                        ->join('topics_agendas', 'topics_agendas.id', '=', 'college_councils.topic_id')
                        ->whereIn('college_councils.status', [2, 3])
                        ->where('topics_agendas.updates', 1)
                        ->select('college_councils.topic_id', DB::raw("
                            CASE
                                WHEN college_councils.created_at > session_topics.created_at THEN 'new'
                                WHEN college_councils.created_at < session_topics.created_at THEN 'old'
                            END as status_category
                        "))
                        ->get();

                    $newAgenda = $returnedAgenda->where('status_category', 'new')->pluck('topic_id')->toArray();
                    $oldAgenda = $returnedAgenda->where('status_category', 'old')->pluck('topic_id')->toArray();
                    $filteredAgenda = array_diff($newAgenda, $oldAgenda);

                    // Step 3: Merge both sets of IDs
                    $finalAgendasIds = array_unique(
                        array_merge($filteredAgendaIds->toArray(), $filteredAgenda)
                    );

                    // Step 4: Apply to query
                    return $query->whereIn('id', $finalAgendasIds)
                        ->whereIn('department_id', $departmentCouncilId);
                } else {
                    abort(403);
                }
            });
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAcceptedTopics::route('/'),
            'view' => Pages\ViewAcceptedTopic::route('/{record}'),
        ];
    }
    public static function getNavigationGroup(): ?string
    {
        return __('Topics Management');
    }
    public static function getLabel(): ?string
    {
        return __('Accepted Topic');
    }

    public static function getPluralLabel(): ?string
    {
        return __('Accepted Topics');
    }

    private static function getFacultyAndDepartmentName()
    {
        return app()->getLocale() == 'en' ? 'en_name' : 'ar_name';
    }

    public static function initializeTopicsWithoutDecision($agendaId): array
    {
        // $topicFormate = SessionTopic::where('session_topics.session_id', $session->id)
        $topicFormate = TopicAgenda::where('topics_agendas.id', $agendaId)
            ->join('topics as sub_topic', 'sub_topic.id', '=', 'topics_agendas.topic_id')
            ->join('control_reports as report', 'report.topic_id', '=', 'sub_topic.id')
            ->join('topics as main_topic', 'main_topic.id', '=', 'sub_topic.main_topic_id')
            ->orderBy('sub_topic.main_topic_id', 'asc') // Order by the `main_topic_id`
            ->select(
                'topics_agendas.id as agenda_id',      // Agenda ID
                'sub_topic.id as topic_id',           // Sub-topic ID
                'sub_topic.title as topic_title',     // Sub-topic Title
                'main_topic.title as main_topic',     // Main-topic Title
                'report.topic_formate'        // Topic format (if exists in `topics_agendas`)
            )
            ->get();

        // Map through all topics and use agenda_id as the key
        $formattedTopics = $topicFormate->mapWithKeys(function ($topic) {
            if (!is_null($topic->topic_formate) && $topic->topic_formate != "<p><br></p>") {
                // Pass individual topic, not grouped
                $replacements = self::getTopicReplacements($topic, $topic->topic_formate);

                // Replace the placeholders with actual values
                $content = self::replacePlaceholders($topic->topic_formate, $replacements);
                $value = strip_tags($content);
            } else {
                $value = $topic->topic_title;
            }

            // Use agenda_id as the key
            return [$topic->agenda_id => $value];
        })->toArray();

        return $formattedTopics;
    }
    public static function replacePlaceholders($content, $replacements)
    {
        foreach ($replacements as $key => $value) {
            $content = str_replace($key, $value, $content);
        }
        return $content;
    }
    public static function getTopicReplacements($topicData, $reportTemplate)
    {
        $agenda = TopicAgenda::findOrFail($topicData->agenda_id);
        $userId = TopicAgenda::where('id', $topicData->agenda_id)->value('created_by');
        $topicTitle = Topic::where('id', $topicData->topic_id)->value('title');
        $topicIds = is_array($topicData->topic_id) ? $topicData->topic_id : [$topicData->topic_id];
        $username = User::where('id', $userId)->value('name');

        // Fetch content and ensure it is properly formatted as an array
        $topicagendacontentform = AgandesTopicForm::where('agenda_id', $topicData->agenda_id)
            ->whereIn('topic_id', $topicIds)
            ->pluck('content')
            ->toArray();

        // Combine all content into a single array of decoded JSON objects
        $decodedContents = [];
        foreach ($topicagendacontentform as $jsonString) {
            // Check if the element is a string and contains JSON
            if (is_string($jsonString)) {
                $decoded = json_decode($jsonString, true);

                if (json_last_error() === JSON_ERROR_NONE) {
                    $decodedContents = array_merge($decodedContents, $decoded);
                } else {
                    // Log or handle invalid JSON
                    return ['error' => 'Invalid JSON content found.'];
                }
            } elseif (is_array($jsonString)) {
                // If it's already an array, just merge it
                $decodedContents = array_merge($decodedContents, $jsonString);
            } else {
                // Handle the case where $jsonString is neither a string nor an array
                return ['error' => 'Unexpected data type encountered.'];
            }
        }


        // Extract all placeholders within curly braces
        preg_match_all('/\{(.*?)\}/', $reportTemplate, $matches);

        $placeholders = $matches[1];


        // Initialize the replacements array
        $replacements = [
            // '{session_number}' => $session->code,
            '{department_name}' => $agenda->departement->ar_name,
            '{faculty_name}' => $agenda->departement->faculty->ar_name,
            '{name_of_topic}' => $topicTitle ?? '',
            // '{deescion_number}' => $decision->order ?? '',
            // '{vote}' => $this->getDecisionStatusMap()[$decision->decision_status] ?? 'حالة غير معروفة',
            // '{vote_type}' => $this->getDecisionTypeStatusMap()[$decision->decision_status] ?? 'حالة غير معروفة',
            // '{justification}' => $decision->decision ?? '',
            // '{decision}' => $decision->decisionChoice ?? '',
            '{uploader}' => $username,
        ];

        // Check if $decodedContents is an array before looping
        if (is_array($decodedContents)) {

            // Search in the decoded content for each placeholder and add it to the replacements
            foreach ($placeholders as $placeholder) {
                foreach ($placeholders as $placeholder) {
                    foreach ($decodedContents as $formField) {

                        $selectableTypes = ['select', 'checkbox-group', 'radio-group'];

                        if (in_array($formField['type'], $selectableTypes)) {
                            $values = $formField['values'];
                            $selectedLabels = [];

                            foreach ($values as $ty) {
                                if (isset($ty['selected']) && $ty['selected'] === true) {
                                    // Collect selected labels
                                    $selectedLabels[] = $ty['label'] ?? '';
                                }
                            }

                            // Implode selected labels into a single string, separated by commas
                            $formField['value'] = implode(', ', $selectedLabels);

                            // Make sure 'label' is set, if not, use the existing label
                            $formField['label'] = $formField['label'] ?? '';

                            if (isset($formField['label']) && $formField['label'] === $placeholder) {
                                // Set the replacement value with the imploded selected values
                                $replacements['{' . $placeholder . '}'] = $formField['value'] ?? '';
                            }
                        } else {
                            if (isset($formField['label']) && $formField['label'] === $placeholder) {
                                $replacements['{' . $placeholder . '}'] = $formField['value'] ?? '';
                                break;
                            }
                        }
                    }
                }
            }
        } else {
            $replacements['error'] = 'Decoded content is not an array.';
        }

        return $replacements;
    }
}