<?php
// Load Composer autoload to access Dotenv
require __DIR__ . '/vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Get DB credentials from .env
$host = $_ENV['DB_HOST'] ?? '127.0.0.1';
$port = $_ENV['DB_PORT'] ?? 3306;
$db   = $_ENV['DB_DATABASE'];
$user = $_ENV['DB_USERNAME'];
$pass = $_ENV['DB_PASSWORD'];

// Connect to MySQL
$mysqli = new mysqli($host, $user, $pass, $db, $port);
if ($mysqli->connect_error) {
    die("❌ Connection failed: " . $mysqli->connect_error);
}

// ✅ Tables you DON'T want to truncate
$excludedTables = [
    'users', // handled separately below
    'migrations',
    'axes',
    'ldap_settings',
    'positions',
    'project_objectives',
    'acadimic_ranks',
    'classification_decisions',
    'control_reports',
    'control_report_faculties',
    'cover_letters',
    'topics',
    'topics_axes',
    'model_has_permissions',
    'permissions',
    'role_has_permissions',
    'model_has_roles',
    'roles',
];

// Step 1: Get all table names
$result = $mysqli->query("SHOW TABLES");
if (!$result) {
    die("❌ Error fetching tables: " . $mysqli->error);
}

// Step 2: Disable foreign key checks
$mysqli->query("SET FOREIGN_KEY_CHECKS = 0");

// Step 3: Loop through tables
while ($row = $result->fetch_array()) {
    $tableName = $row[0];

    if ($tableName === 'users') {
        // 👤 Special handling: delete all users except id = 1
        $deleteQuery = "DELETE FROM `users` WHERE `id` != 1";
        if ($mysqli->query($deleteQuery) === TRUE) {
            echo "🧹 Deleted all users except ID 1\n";
        } else {
            echo "⚠️ Failed to delete users: " . $mysqli->error . "\n";
        }
        continue;
    }

    if (!in_array($tableName, $excludedTables)) {
        if ($mysqli->query("TRUNCATE TABLE `$tableName`") === TRUE) {
            echo "🧹 Cleared table: $tableName\n";
        } else {
            echo "⚠️ Failed to truncate $tableName: " . $mysqli->error . "\n";
        }
    } else {
        echo "⏸ Skipped table: $tableName\n";
    }
}

// Step 4: Re-enable foreign key checks
$mysqli->query("SET FOREIGN_KEY_CHECKS = 1");

echo "\n✅ Database cleanup complete.\n";

$mysqli->close();
