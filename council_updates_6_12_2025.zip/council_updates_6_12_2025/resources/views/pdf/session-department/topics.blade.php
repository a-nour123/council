<!doctype html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>جدول اعمال جلسة القسم</title>

    <style>
        /* General Layout */
        @page {
            margin: 20mm 15mm 25mm 15mm;
        }

        * {
            box-sizing: border-box;
            font-family: 'DejaVu Sans', 'Arial', sans-serif;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'DejaVu Sans', 'Arial', sans-serif;
            direction: rtl;
            margin: 0;
            padding: 0;
            line-height: 1.8;
        }

        .cover-wrapper {
            max-width: 900px;
            padding: 20px;
            border: 2px solid #000;
            background-color: #fff;
            direction: rtl;
            page-break-after: always;
        }

        .cover-wrapper-footer {
            page-break-inside: avoid;
            page-break-before: always;
            max-height: 100vh;
            max-width: 900px;
            padding: 20px;
            border: 2px solid #000;
            background-color: #fff;
            direction: rtl;
        }

        .main-content {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            direction: rtl;
            text-align: right;
        }

        .cover-wrapper {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .cover-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #000;
            padding: 1px 54px;
        }

        .arabic-section,
        .english-section {
            flex: 1;
            text-align: center;
        }

        .college-logo {
            height: 120px;
            margin: 0 30px;
        }

        .arabic-text,
        .english-text {
            font-size: 13px;
            font-weight: bold;
            margin: 0px;
            line-height: 20px;
            white-space: normal;
            word-wrap: break-word;
        }

        .arabic-text {
            color: black;
        }

        .english-text {
            color: black;
        }

        .centered-section {
            text-align: center;
        }

        .centered-text {
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0;
            color: black;
            white-space: normal;
            word-wrap: break-word;
        }

        .session-details {
            font-size: 16px;
            color: black;
            margin-top: 20px;
            white-space: normal;
            word-wrap: break-word;
        }

        .session-header {
            font-weight: bold;
            font-size: 18px;
            margin: 10px 0;
            white-space: normal;
            word-wrap: break-word;
        }

        .session-info {
            margin-top: 10px;
            line-height: 1.6;
            white-space: normal;
            word-wrap: break-word;
        }

        .college-message {
            text-align: center;
            margin: 30px 0;
        }

        .message-header {
            font-size: 20px;
            font-weight: bold;
            color: black;
            white-space: normal;
            word-wrap: break-word;
        }

        .message-body {
            font-size: 18px;
            line-height: 1.8;
            color: #c00505;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            table-layout: fixed;
        }

        table th,
        table td {
            padding: 8px;
            text-align: center;
            border: 1px solid #000;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        h3 {
            margin-top: 20px;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        h2 {
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        p {
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .text-primary {
            color: black;
        }

        .text-success {
            color: black;
        }

        .page-break {
            page-break-before: always;
        }

        .simple-table {
            width: 100%;
            border-collapse: collapse;
            font-family: 'DejaVu Sans', 'Arial', sans-serif;
            font-size: 14px;
            text-align: center;
            margin-top: 20px;
            table-layout: fixed;
        }

        .simple-table thead th {
            background-color: #f4f4f4;
            border: 1px solid #ddd;
            padding: 10px;
            font-weight: bold;
            white-space: normal;
            word-wrap: break-word;
        }

        .simple-table tbody td {
            padding: 8px;
            border: 1px solid #ddd;
            color: black;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .simple-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        ol {
            list-style-type: none;
            padding-left: 0;
            margin-left: 0;
        }

        ol li {
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .bordered-div {
            border: 2px solid #000;
            padding: 20px;
            margin: 20px 0;
            width: fit-content;
            text-align: center;
            border-radius: 8px;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .ql-align-center {
            text-align: center;
        }

        .ql-align-right {
            text-align: right;
        }

        .ql-align-justify {
            text-align: justify;
        }

        .hidden-table {
            border-collapse: collapse;
            width: 100%;
            border: none;
        }

        .hidden-table td {
            border: none !important;
        }

        .topic-page {
            page-break-before: always;
        }
    </style>

</head>

<body>
    @php
        use Alkoumi\LaravelHijriDate\Hijri;
        use Carbon\Carbon;
        use App\Models\Department;
        use App\Models\YearlyCalendar;
        use App\Models\Faculty;

        $endDateTime = Carbon::parse($data['session']->actual_end_time);
        $startDateTime = Carbon::parse($data['session']->start_time);

        $hijriEndDateTime = Hijri::DateIndicDigits('Y/m/d', $endDateTime->format('Y/m/d'));
        $higriDate = Hijri::DateIndicDigits('Y/m/d', $startDateTime->format('Y/m/d'));
        $dayName = Hijri::DateIndicDigits('l', $startDateTime->format('l'));
        $startTime = $startDateTime->format('g:i A');
        $startTime = str_replace(['AM', 'PM'], ['ص', 'م'], $startTime);
        $startDate = $startDateTime->format('Y/m/d');
        $parts = explode('_', $data['session']->code);
        $department = Department::findOrFail($data['session']->department_id);
        $faculty = Faculty::where('id', $department->faculty_id)->first();
        $departmentMessage = $department->message;

        $yearCode = $parts[0];
        $departmentCode = $parts[1];
        $lastPart = $parts[2];

        $yearName = YearlyCalendar::where('code', $yearCode)->value('name');
        $departmentArName = Department::where('code', $departmentCode)->value('ar_name');

        $newSessionCode = "{$yearName}_{$departmentArName}_{$lastPart}";
    @endphp
    <div class="container">
        <!-- Cover Page -->
        <div class="cover-wrapper" style="margin:100px auto">
            <!-- Header Section -->
            <div class="cover-header" style="margin-bottom:100px">
                <table class="hidden-table">
                    <tr>
                        <td class="arabic-section">
                            <div class="arabic-text">المملكة العربية السعودية</div>
                            <div class="arabic-text">وزارة التعليم</div>
                            <div class="arabic-text">جامعة القصيم</div>
                            <div class="arabic-text">{{ $faculty->ar_name }}</div>
                            <div class="arabic-text">{{ $department->ar_name }}</div>
                        </td>

                        <td class="logo-section">
                            <img src="{{ public_path('assets/logo.png') }}" alt="College Logo" class="college-logo">
                        </td>

                        <td class="english-section">
                            <div class="english-text">Kingdom of Saudi Arabia</div>
                            <div class="english-text">Ministry of Education</div>
                            <div class="english-text">Qassim University</div>
                            <div class="english-text">{{ $faculty->en_name }}</div>
                            <div class="english-text">{{ $department->en_name }}</div>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="centered-section" style="margin:20px auto 0px">
                <div class="centered-text">
                    بسم الله الرحمن الرحيم
                </div>

                <div class="session-details bordered-div" style="margin-top: 80px">
                    <div class="session-header">
                        {{ $data['session']->department->faculty->ar_name }} / مجلس
                        {{ $data['session']->department->ar_name }}
                    </div>
                    <span style="font-size: 18px">محضر</span>
                    <div class="session-info">
                        {{ $data['sessionOrder'] }} للعام الجامعى {{ $yearName }}<br>
                        المنعقدة يوم {{ $dayName }} {{ $higriDate }} هـ الموافق {{ $startDate }} م
                    </div>
                </div>
            </div>

            <div class="college-message" style="margin:100px auto 100px">
                <div class="message-header">رسالة القسم</div>
                <div class="message-body bordered-div" style="margin-bottom: 300px; color: #000;">
                    {!! $departmentMessage !!}
                </div>
            </div>
        </div>

        <!-- Main Content Starts Here -->
        <div class="main-content" style="margin-bottom:10px ">
            <div class="cover-header">
                <table class="hidden-table">
                    <tr>
                        <td class="arabic-section">
                            <div class="arabic-text">المملكة العربية السعودية</div>
                            <div class="arabic-text">وزارة التعليم</div>
                            <div class="arabic-text">جامعة القصيم</div>
                            <div class="arabic-text">{{ $faculty->ar_name }}</div>
                            <div class="arabic-text">{{ $department->ar_name }}</div>
                        </td>

                        <td class="logo-section">
                            <img src="{{ public_path('assets/logo.png') }}" alt="College Logo" class="college-logo">
                        </td>

                        <td class="english-section">
                            <div class="english-text">Kingdom of Saudi Arabia</div>
                            <div class="english-text">Ministry of Education</div>
                            <div class="english-text">Qassim University</div>
                            <div class="english-text">{{ $faculty->en_name }}</div>
                            <div class="english-text">{{ $department->en_name }}</div>
                        </td>
                    </tr>
                </table>
            </div>

            <h2 style="text-align: center;margin-bottom:9px;margin-top: 16px;">مناقشة جدول الأعمال</h2>
            <p style="text-align: center;">وتم استعراض جدول الأعمال ومناقشة ما ورد فيه واتخذ مجلس القسم القرارات
                والتوصيات وفق ما يلي :</p>

            <table class="simple-table">
                <thead>
                    <tr>
                        <th>ترتيب الموضوع</th>
                        <th>عنوان الموضوع</th>
                    </tr>
                </thead>
                <tbody>
                    @php $i = 1; @endphp
                    @foreach ($data['topics'] as $mainTopic => $supTopics)
                        <tr>
                            <td colspan="2" class="text-center"><strong>{{ $mainTopic }}</strong></td>
                        </tr>
                        @foreach ($supTopics['details'] as $topic)
                            <tr>
                                <td>{{ $data['arabicOrder'][$i] }}</td>
                                <td>{!! strip_tags($topic['topic_title']) !!}</td>
                            </tr>
                            @php $i++; @endphp
                        @endforeach
                    @endforeach
                </tbody>
            </table>

            @php $i = 1; @endphp
            @foreach ($data['topics'] as $mainTopic => $supTopics)
                @foreach ($supTopics['details'] as $topic)
                    <div class="topic-page">
                        <div class="cover-header" style="margin-bottom:20px;">
                            <table class="hidden-table">
                                <tr>
                                    <td class="arabic-section">
                                        <div class="arabic-text">المملكة العربية السعودية</div>
                                        <div class="arabic-text">وزارة التعليم</div>
                                        <div class="arabic-text">جامعة القصيم</div>
                                        <div class="arabic-text">{{ $faculty->ar_name }}</div>
                                        <div class="arabic-text">{{ $department->ar_name }}</div>
                                    </td>

                                    <td class="logo-section">
                                        <img src="{{ public_path('assets/logo.png') }}" alt="College Logo"
                                            class="college-logo">
                                    </td>

                                    <td class="english-section">
                                        <div class="english-text">Kingdom of Saudi Arabia</div>
                                        <div class="english-text">Ministry of Education</div>
                                        <div class="english-text">Qassim University</div>
                                        <div class="english-text">{{ $faculty->en_name }}</div>
                                        <div class="english-text">{{ $department->en_name }}</div>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <center>
                            <div
                                style="background-color: #f5f5f5; border-bottom: 1px solid; padding: 10px; border-radius: 5px; position: relative; text-align: center;">
                                <h3 style="margin: 0; font-weight: bold; position: relative; z-index: 1;">
                                    {{ $mainTopic }}
                                </h3>
                            </div>
                        </center>

                        <h3 style="margin-top:24px">الموضوع {{ $data['arabicOrder'][$i] }} : {!! strip_tags($topic['topic_title']) !!}
                        </h3>

                        <ol>
                            <li style="margin-top: 16px;">
                                {!! $topic['report_contents'] !!}
                            </li>
                        </ol>
                        <hr style="border: none; border-top: 2px solid #ccc; width: 100%; margin: 15px auto;">

                        @php $i++; @endphp
                    </div>
                @endforeach
            @endforeach

            <h3 style="text-align: center;" class="text-success mt-4">تم اعتماد المحضر
                بتاريخ:<span>{{ $hijriEndDateTime }}</span>
            </h3>
            <h3 style="text-align: center;" class="text-success mt-4">
                معد المحضر:
                {{ $data['session']->createdBy->ar_name }}
            </h3>

        </div>
    </div>
</body>

</html>
