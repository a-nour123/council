<!DOCTYPE html>
<html dir="rtl">

<head>
    <meta charset="UTF-8">
    <style>
        body {
            margin: 0;
            padding: 5px 15px;
            font-family: 'DejaVu Sans', 'Arial', sans-serif;
            font-size: 14px;
            font-weight: 550;
            text-align: center;
            direction: rtl;
        }

        .footer-content {
            border-top: 1px solid #ddd;
            padding-top: 5px;
            color: #666;
        }
    </style>
</head>

<body>
    <div class="footer-content">
        محضر {{ $sessionOrder }} - {{ $departmentName }} / {{ $facultyName }}
    </div>
</body>

</html>
