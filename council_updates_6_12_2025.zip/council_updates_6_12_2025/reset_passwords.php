<?php
// Load Composer autoload to access Dotenv
require __DIR__ . '/vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Get DB credentials from .env
$host = $_ENV['DB_HOST'] ?? '127.0.0.1';
$port = $_ENV['DB_PORT'] ?? 3306;
$db   = $_ENV['DB_DATABASE'];
$user = $_ENV['DB_USERNAME'];
$pass = $_ENV['DB_PASSWORD'];

// Connect to MySQL
$mysqli = new mysqli($host, $user, $pass, $db, $port);
if ($mysqli->connect_error) {
    die("❌ Connection failed: " . $mysqli->connect_error);
}

echo "🔐 Starting password reset...\n";

$hash = "$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi" ?? null;

if (!$hash) {
    die("❌ GLOBAL_PASSWORD_HASH is missing in .env\n");
}

// Update users table
// ❗ Keep ID = 1 unchanged or change if you want
// $query = "UPDATE users SET password = '$hash' WHERE id != 1";
$query = "UPDATE users SET password = '$hash'";


if ($mysqli->query($query) === TRUE) {
    // echo "✅ All user passwords updated (except user ID 1)\n";
    echo "✅ All user passwords updated\n";
} else {
    echo "⚠️ Error updating passwords: " . $mysqli->error . "\n";
}

$mysqli->close();

echo "🏁 Done.\n";
