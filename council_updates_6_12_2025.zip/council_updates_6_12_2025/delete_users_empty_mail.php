<?php
// Load Composer autoload to access Dotenv
require __DIR__ . '/vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Get DB credentials from .env
$host = $_ENV['DB_HOST'] ?? '127.0.0.1';
$port = $_ENV['DB_PORT'] ?? 3306;
$db   = $_ENV['DB_DATABASE'];
$user = $_ENV['DB_USERNAME'];
$pass = $_ENV['DB_PASSWORD'];

// Connect to MySQL
$mysqli = new mysqli($host, $user, $pass, $db, $port);
if ($mysqli->connect_error) {
    die("❌ Connection failed: " . $mysqli->connect_error);
}

echo "🧹 Starting cleanup...\n";

// Delete users where email is NULL
$query = "DELETE FROM users WHERE email IS NULL";

if ($mysqli->query($query) === TRUE) {
    echo "✅ Deleted all users with NULL email.\n";
} else {
    echo "⚠️ Error deleting users: " . $mysqli->error . "\n";
}

$mysqli->close();

echo "🏁 Done.\n";
