<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mail_settings', function (Blueprint $table) {
            $table->id();

            $table->string('mailer')->nullable();      // smtp, exchange
            $table->string('host')->nullable();        // smtp.gmail.com
            $table->integer('port')->nullable();       // 587

            $table->string('username')->nullable();    // mail@mail.com
            $table->text('password')->nullable();      // encrypted password

            $table->string('encryption')->nullable();  // null, ssl, tls, starttls

            $table->string('from_address')->nullable(); // mail@mail.com
            $table->string('from_name')->nullable();    // Name of From

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mail_settings');
    }
};
