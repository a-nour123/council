<?php

namespace App\Filament\Resources\FacultyCouncilReportResource\Pages;

use App\Filament\Resources\FacultyCouncilReportResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFacultyCouncilReport extends CreateRecord
{
    protected static string $resource = FacultyCouncilReportResource::class;
}
