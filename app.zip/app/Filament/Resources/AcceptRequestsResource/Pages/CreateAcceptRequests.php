<?php

namespace App\Filament\Resources\AcceptRequestsResource\Pages;

use App\Filament\Resources\AcceptRequestsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAcceptRequests extends CreateRecord
{
    protected static string $resource = AcceptRequestsResource::class;
}
