<?php

namespace App\Filament\Resources\AxisResource\Pages;

use Filament\Resources\Pages\EditRecord;
use App\Filament\Resources\AxisResource;

class EditAxesPage extends EditRecord
{
    protected static string $resource = AxisResource::class;

}



