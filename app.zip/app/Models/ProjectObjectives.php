<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProjectObjectives extends Model
{
    protected $table = 'project_objectives';
    public $timestamps = false; 
}
