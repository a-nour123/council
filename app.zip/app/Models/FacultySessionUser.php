<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Relations\Pivot;

class FacultySessionUser extends Pivot
{
    //

    protected $table = 'faculty_session_users';

}
