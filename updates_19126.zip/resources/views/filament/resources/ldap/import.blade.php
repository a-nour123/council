<x-filament::page>
    <?php
$langData = [];
$locale = app()->getLocale();
$langFile = $locale == 'ar' ? __DIR__ . '/../../../lang/ar.json' : __DIR__ . '/../../../lang/en.json';

if (file_exists($langFile)) {
    $langData = json_decode(file_get_contents($langFile), true);
} else {
    echo "Language file for '$locale' not found!";
}
    ?>

    <div class="p-8 bg-gradient-to-br from-white via-gray-50 to-white rounded-2xl shadow-xl border border-gray-100">
        <form action="">
            @csrf
            <!-- Action Buttons -->
            <div
                class="mb-6 flex flex-wrap gap-3 justify-between items-center p-4 bg-gradient-to-r from-gray-50 to-white rounded-xl border border-gray-200">
                <div class="flex gap-2">
                    <button type="button" id="selectAll"
                        class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-gray-700 bg-white border-2 border-gray-300 rounded-lg hover:bg-gray-50 hover:border-gray-400 hover:shadow-md transition-all duration-200 transform hover:scale-105">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <?= $langData['Select All'] ?>
                    </button>
                    <button type="button" id="deselectAll"
                        class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-gray-700 bg-white border-2 border-gray-300 rounded-lg hover:bg-gray-50 hover:border-gray-400 hover:shadow-md transition-all duration-200 transform hover:scale-105">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <?= $langData['Deselect All'] ?>
                    </button>
                </div>
                <button type="submit"
                    class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-gray-700 bg-white border-2 border-gray-300 rounded-lg hover:bg-gray-50 hover:border-gray-400 hover:shadow-md transition-all duration-200 transform hover:scale-105">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                    </svg>
                    <?= $langData['Import Selected Users'] ?>
                </button>
            </div>

            <!-- Table Container -->
            <div class="overflow-hidden rounded-xl border-2 border-gray-200 shadow-2xl bg-white">
                <div class="overflow-x-auto">
                    <table id="ldapUsersTable" class="min-w-full w-full text-sm">
                        <thead
                            class="text-xs font-bold text-gray-700 uppercase bg-gradient-to-r from-gray-100 via-gray-50 to-gray-100 border-b-2 border-gray-300">
                            <tr>
                                <th scope="col" class="p-4 text-center">
                                    <span class="sr-only"><?= $langData['Select'] ?></span>
                                </th>
                                <th scope="col" class="py-4 px-6 text-center"><?= $langData['Username'] ?></th>
                                <th scope="col" class="py-4 px-6 text-center"><?= $langData['Name'] ?></th>
                                <th scope="col" class="py-4 px-6 text-center"><?= $langData['Arabic Name'] ?></th>
                                <th scope="col" class="py-4 px-6 text-center"><?= $langData['English Name'] ?></th>
                                <th scope="col" class="py-4 px-6 text-center"><?= $langData['Email'] ?></th>
                                <th scope="col" class="py-4 px-6 text-center"><?= $langData['Acadimic rank'] ?></th>
                                <th scope="col" class="py-4 px-6 text-center"><?= $langData['Status'] ?></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 text-center"></tbody>
                    </table>
                </div>
            </div>
        </form>
    </div>

    <script src="{{ URL::asset('assets/js/jquery-3.6.0.min.js') }}"></script>
    <script src="{{ URL::asset('assets/js/jquery-ui.min.js') }}"></script>
    <link rel="stylesheet" href="{{ URL::asset('assets/css/sweetalert2.min.css') }}">
    <script src="{{ URL::asset('assets/js/sweetalert2.min.js') }}"></script>
    <script src="{{ URL::asset('assets/js/quill.min.js') }}"></script>
    <script src="{{ URL::asset('assets/js/flowbite.min.js') }}"></script>
    <link rel="stylesheet" href="{{ URL::asset('assets/css/quill.snow.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('assets/css/select2.min.css') }}">
    <script src="{{ URL::asset('assets/js/select2.min.js') }}"></script>
    <link rel="stylesheet" href="{{ URL::asset('assets/DataTables/datatables.min.css') }}">
    <script src="{{ URL::asset('assets/DataTables/DataTables-1.13.8/js/jquery.dataTables.min.js') }}"></script>

    <script>
        var $langData = {
            'Success': `<?= $langData['Success'] ?>`,
            'saving data': `<?= $langData['saving data'] ?>`,
            'ok': `<?= $langData['ok'] ?>`,
            'Cancel': `<?= $langData['Cancel'] ?>`,
            'Confirm': `<?= $langData['Confirm'] ?>`,
            'Add another': `<?= $langData['Add another'] ?>`,
            'error': `<?= $langData['error'] ?>`,
            'Importing users, please wait...': `<?= $langData['Importing users, please wait...'] ?>`,
            'Please select at least one user to import': `<?= $langData['Please select at least one user to import'] ?>`,
            'processing': `<?= $langData['processing'] ?>`,
            'Are you sure you want to import the selected users?': `<?= $langData['Are you sure you want to import the selected users?'] ?>`,
            'Users imported successfully!': `<?= $langData['Users imported successfully!'] ?>`,
            'An error occurred. Please try again.': `<?= $langData['An error occurred. Please try again.'] ?>`,
            'Failed Imports': `<?= $langData['Failed Imports'] ?>`,
        };

        $(document).ready(function () {
            // Persist selection across pages
            const selectedUsersMap = {};

            // Initialize DataTable with server-side processing
            const table = $('#ldapUsersTable').DataTable({
                processing: true,
                serverSide: true,
                searching: true,
                lengthChange: true,
                pageLength: 10,
                lengthMenu: [[5, 10, 25, 50, 100, -1], [5, 10, 25, 50, 100, "{{ __('All') }}"]],
                dom: '<"datatable-top"lf>rt<"datatable-bottom"ip>',
                language: {
                    processing: "{{ __('processing') }}",
                    emptyTable: "{{ __('No data available in table') }}",
                    zeroRecords: "{{ __('No matching records found') }}",
                    loadingRecords: "{{ __('Loading...') }}",
                    search: "_INPUT_",
                    searchPlaceholder: "{{ __('Search...') }}",
                    lengthMenu: "{{ __('Show') }} _MENU_ {{ __('entries') }}",
                    info: "{{ __('Showing _START_ to _END_ of _TOTAL_ entries') }}",
                    infoEmpty: "{{ __('Showing 0 to 0 of 0 entries') }}",
                    infoFiltered: "{{ __('(filtered from _MAX_ total entries)') }}",
                    paginate: {
                        first: "{{ __('First') }}",
                        last: "{{ __('Last') }}",
                        next: "{{ __('Next') }}",
                        previous: "{{ __('Previous') }}"
                    }
                },
                ajax: {
                    url: `{{ route('ldap-settings.usersData') }}`,
                    type: 'POST',
                    data: function (d) {
                        d._token = $('input[name="_token"]').val();
                    },
                    error: function (xhr, status, error) {
                        let message = 'Ajax error';
                        if (xhr.responseJSON) {
                            message = xhr.responseJSON.message || JSON.stringify(xhr.responseJSON);
                        } else if (xhr.responseText) {
                            message = xhr.responseText.substring(0, 800);
                        }
                        Swal.fire({
                            title: $langData.error,
                            text: message,
                            icon: 'error',
                            confirmButtonText: $langData.ok,
                        });
                    }
                },
                columns: [{
                    data: null,
                    orderable: false,
                    searchable: false,
                    className: 'text-center',
                    render: function (data, type, row, meta) {
                        if (row.exist) {
                            return '';
                        }
                        const checked = selectedUsersMap[row.username] ? 'checked' : '';
                        return `<input type="checkbox" class="ldap-user-checkbox w-4 h-4 text-primary-600 bg-gray-100 border-gray-300 rounded focus:ring-primary-500" value="${row.username}" ${checked}>`;
                    }
                },
                {
                    data: 'username',
                    className: 'font-medium text-gray-900'
                },
                {
                    data: 'name'
                },
                {
                    data: 'ar_name'
                },
                {
                    data: 'en_name'
                },
                {
                    data: 'email'
                },
                {
                    data: 'acadimic_rank'
                },
                {
                    data: 'exist',
                    orderable: false,
                    render: function (exist) {
                        if (exist) {
                            return `<span class="status-badge status-exist"><?= $langData['Already exists in system'] ?></span>`;
                        }
                        return `<span class="status-badge status-new"><?= $langData['New user'] ?></span>`;
                    }
                }
                ],
                order: [
                    [1, 'asc']
                ],
                initComplete: function () {
                    // Apply styles after table initialization
                    applyDataTableStyles();
                },
                drawCallback: function () {
                    // Apply styles on each redraw
                    applyDataTableStyles();

                    // Re-bind checkbox change handler on each draw
                    $('#ldapUsersTable .ldap-user-checkbox').off('change').on('change', function () {
                        const row = $(this).closest('tr');
                        const rowData = table.row(row).data();
                        const username = rowData.username;
                        if (this.checked) {
                            selectedUsersMap[username] = {
                                username: rowData.username,
                                name: rowData.name || '',
                                ar_name: rowData.ar_name || '',
                                en_name: rowData.en_name || '',
                                email: rowData.email || '',
                                acadimic_rank: (rowData.acadimic_rank || '') === '-' ? '' : (rowData.acadimic_rank || '')
                            };
                        } else {
                            delete selectedUsersMap[username];
                        }
                    });
                }
            });

            // Function to apply DataTable styles
            function applyDataTableStyles() {
                // Style the search input with icon
                const $filterLabel = $('.dataTables_filter label');
                const $filterInput = $('.dataTables_filter input');
                $filterInput.removeClass();
                $filterInput.addClass('pl-10 pr-4 py-2.5 border-2 border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500 text-sm w-75 transition-all duration-200');
                $filterInput.attr('placeholder', '🔍 {{ __("Search users...") }}');

                // Remove label text, keep only input
                $filterLabel.contents().filter(function () {
                    return this.nodeType === 3;
                }).remove();

                // Style the length select with label
                const $lengthLabel = $('.dataTables_length label');
                const $lengthSelect = $('.dataTables_length select');
                $lengthSelect.removeClass();
                $lengthSelect.addClass('px-4 py-2.5 border-2 border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500 text-sm font-medium bg-white transition-all duration-200');

                // Style the info text
                $('.dataTables_info').removeClass().addClass('text-sm font-medium text-gray-600 bg-gray-50 px-4 py-2 rounded-lg');

                // Style pagination with modern design
                $('.dataTables_paginate').find('.paginate_button').each(function () {
                    const $btn = $(this);
                    $btn.removeClass();

                    if ($btn.hasClass('current')) {
                        $btn.addClass('px-4 py-2 text-sm font-bold text-white bg-gradient-to-r from-primary-600 to-primary-700 border-2 border-primary-600 rounded-lg shadow-md hover:shadow-lg mx-1 transition-all duration-200 transform hover:scale-105');
                    } else if ($btn.hasClass('disabled')) {
                        $btn.addClass('px-4 py-2 text-sm font-medium text-gray-400 bg-gray-100 border-2 border-gray-200 rounded-lg cursor-not-allowed mx-1 opacity-50');
                    } else {
                        $btn.addClass('px-4 py-2 text-sm font-semibold text-gray-700 bg-white border-2 border-gray-300 rounded-lg hover:bg-gray-50 hover:border-primary-400 hover:shadow-md mx-1 transition-all duration-200 transform hover:scale-105');
                    }
                });
            }

            const selectAllBtn = $('#selectAll');
            const deselectAllBtn = $('#deselectAll');
            const checkboxes = $('input[name="selected_users[]"]');
            const form = $('form');

            // Select All (current page)
            selectAllBtn.on('click', function () {
                $('#ldapUsersTable .ldap-user-checkbox').each(function () {
                    const $cb = $(this);
                    const rowData = table.row($cb.closest('tr')).data();
                    $cb.prop('checked', true);
                    selectedUsersMap[rowData.username] = {
                        username: rowData.username,
                        name: rowData.name || '',
                        ar_name: rowData.ar_name || '',
                        en_name: rowData.en_name || '',
                        email: rowData.email || '',
                        acadimic_rank: (rowData.acadimic_rank || '') === '-' ? '' : (rowData.acadimic_rank || '')
                    };
                });
            });

            // Deselect All (current page)
            deselectAllBtn.on('click', function () {
                $('#ldapUsersTable .ldap-user-checkbox').each(function () {
                    const $cb = $(this);
                    const rowData = table.row($cb.closest('tr')).data();
                    $cb.prop('checked', false);
                    delete selectedUsersMap[rowData.username];
                });
            });

            // SweetAlert with AJAX
            form.on('submit', function (e) {
                e.preventDefault(); // Prevent default form submission

                const selectedUsersArray = Object.values(selectedUsersMap);

                if (selectedUsersArray.length === 0) {
                    Swal.fire({
                        title: $langData.error,
                        text: '<?= $langData['Please select at least one user to import'] ?>',
                        icon: 'error',
                        confirmButtonText: $langData.ok,
                        confirmButtonColor: '#d33' // Red error button color
                    });
                    return;
                }

                // Use persisted selections as usersData
                let usersData = selectedUsersArray;

                Swal.fire({
                    title: $langData['saving data'],
                    text: '<?= $langData['Are you sure you want to import the selected users?'] ?>',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: $langData.Confirm,
                    cancelButtonText: $langData.Cancel,
                    confirmButtonColor: '#3085d6', // Blue color
                    cancelButtonColor: '#d33' // Red color
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: `{{ route('ldap-settings.importUsers') }}`,
                            type: "post",
                            data: {
                                _token: $('input[name="_token"]').val(),
                                users: usersData
                            },
                            beforeSend: function () {
                                Swal.fire({
                                    title: $langData['processing'],
                                    text: $langData['Importing users, please wait...'],
                                    icon: 'info',
                                    showConfirmButton: false,
                                    allowOutsideClick: false
                                });
                            },
                            success: function (response) {
                                let message = `<p>${response.message}</p>`;

                                // Check if there are failed imports and display them properly
                                if (response.failed_imports && response.failed_imports.length > 0) {
                                    message += `<hr><strong>${$langData['Failed Imports'] ?? 'Failed Imports'}:</strong><ul style="text-align:left;">`;
                                    response.failed_imports.forEach(user => {
                                        message += `<li><strong>${user.username}</strong>: ${user.reason}</li>`;
                                    });
                                    message += `</ul>`;
                                }

                                Swal.fire({
                                    title: response.success ? ($langData['Success'] ?? 'Success') : ($langData['Warning'] ?? 'Warning'),
                                    html: message, // Use `html` to format content
                                    icon: response.success ? 'success' : 'warning',
                                    showConfirmButton: true,
                                    allowOutsideClick: false, // Prevent clicking outside
                                    confirmButtonText: $langData['ok'] ?? 'OK',
                                    confirmButtonColor: '#3085d6'
                                }).then(() => {
                                    location.reload(); // Reload after confirmation
                                });
                            },
                            error: function (xhr) {
                                let errorMessage = $langData['An error occurred. Please try again.'];
                                if (xhr.responseJSON && xhr.responseJSON.message) {
                                    errorMessage = xhr.responseJSON.message;
                                }
                                Swal.fire({
                                    title: $langData.error,
                                    text: errorMessage,
                                    icon: 'error',
                                    confirmButtonText: $langData.ok,
                                    confirmButtonColor: '#d33'
                                });
                            }
                        });
                    }
                });
            });
        });
    </script>

    <style>
        /* Status badges with animations */
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 14px;
            border-radius: 9999px;
            font-size: 12px;
            font-weight: 700;
            border: 2px solid transparent;
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .status-exist {
            background: linear-gradient(135deg, #ffe5e5 0%, #ffd0d0 100%);
            color: #b91c1c;
            border-color: #f5c2c2;
        }

        .status-exist:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(185, 28, 28, 0.2);
        }

        .status-new {
            background: linear-gradient(135deg, #e5ffe5 0%, #d0ffd0 100%);
            color: #166534;
            border-color: #a3e6a3;
            animation: pulse-green 2s ease-in-out infinite;
        }

        .status-new:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(22, 101, 52, 0.2);
        }

        @keyframes pulse-green {

            0%,
            100% {
                box-shadow: 0 2px 4px rgba(22, 101, 52, 0.1);
            }

            50% {
                box-shadow: 0 4px 12px rgba(22, 101, 52, 0.3);
            }
        }

        /* DataTable container styling */
        .datatable-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            gap: 1.5rem;
            padding: 1rem;
            background: linear-gradient(135deg, #f9fafb 0%, #ffffff 100%);
            border-radius: 0.75rem;
            border: 1px solid #e5e7eb;
        }

        .datatable-bottom {
            display: flex;
            flex-wrap: nowrap;
            align-items: center;
            justify-content: space-between;
            margin-top: 1.5rem;
            padding: 1rem;
            background: linear-gradient(135deg, #f9fafb 0%, #ffffff 100%);
            border-radius: 0.75rem;
            border-top: 2px solid #e5e7eb;
            gap: 1rem;
        }

        /* Remove default DataTables styling */
        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_filter {
            margin: 0;
        }

        .dataTables_wrapper .dataTables_paginate {
            margin: 0;
        }

        /* Enhanced table row styling */
        #ldapUsersTable tbody tr {
            transition: all 0.3s ease;
            cursor: pointer;
        }

        #ldapUsersTable tbody tr:hover {
            background: linear-gradient(90deg, #f0f9ff 0%, #e0f2fe 50%, #f0f9ff 100%);
            transform: scale(1.01);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }

        #ldapUsersTable tbody td {
            padding: 1rem 1.5rem;
            vertical-align: middle;
        }

        /* Checkbox styling */
        .ldap-user-checkbox {
            width: 1.25rem;
            height: 1.25rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .ldap-user-checkbox:hover {
            transform: scale(1.15);
        }

        .ldap-user-checkbox:checked {
            animation: checkboxPop 0.3s ease;
        }

        @keyframes checkboxPop {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.2);
            }
        }

        /* Processing indicator */
        .dataTables_processing {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(249, 250, 251, 0.95) 100%);
            border: 2px solid #e5e7eb;
            border-radius: 1rem;
            padding: 1.5rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            backdrop-filter: blur(10px);
        }

        /* Loading animation */
        @keyframes shimmer {
            0% {
                background-position: -1000px 0;
            }

            100% {
                background-position: 1000px 0;
            }
        }

        .dataTables_processing::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.5), transparent);
            animation: shimmer 2s infinite;
        }

        /* Smooth scrollbar */
        .overflow-x-auto::-webkit-scrollbar {
            height: 8px;
        }

        .overflow-x-auto::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 10px;
        }

        .overflow-x-auto::-webkit-scrollbar-thumb {
            background: linear-gradient(90deg, #cbd5e1, #94a3b8);
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .overflow-x-auto::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(90deg, #94a3b8, #64748b);
        }

        /* Add subtle entrance animation */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        #ldapUsersTable tbody tr {
            animation: fadeInUp 0.5s ease-out;
        }
    </style>

</x-filament::page>