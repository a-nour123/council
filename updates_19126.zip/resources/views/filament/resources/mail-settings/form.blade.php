<x-filament::page>
    <?php
    $langData = [];
    $locale = app()->getLocale();
    $langFile = $locale == 'ar' ? __DIR__ . '/../../../lang/ar.json' : __DIR__ . '/../../../lang/en.json';

    if (file_exists($langFile)) {
        $langData = json_decode(file_get_contents($langFile), true);
    }

    $mailers = ['smtp', 'exchange']; // Allowed mailers
    $encryptions = ['null', 'ssl', 'tls', 'starttls']; // Allowed encryptions
    ?>

    <div class="p-6">
        <div class="p-6 bg-white shadow-lg rounded-lg max-w-4xl mx-auto">
            <form action="" class="space-y-6">
                @csrf
                <input type="hidden" name="id" value="{{ $mailSettings['id'] ?? '' }}">

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Mailer Select -->
                    <div>
                        <label for="mailer" class="block text-sm font-medium text-gray-700">Mailer</label>
                        <select name="mailer" id="mailer" required class="w-full mt-1 p-2 border rounded-md">
                            @foreach ($mailers as $mailer)
                                <option value="{{ $mailer }}"
                                    {{ ($mailSettings['mailer'] ?? 'smtp') === $mailer ? 'selected' : '' }}>
                                    {{ strtoupper($mailer) }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Host -->
                    <div>
                        <label for="host" class="block text-sm font-medium text-gray-700">Host</label>
                        <input type="text" name="host" id="host" value="{{ $mailSettings['host'] ?? '' }}"
                            required placeholder="smtp.mail.com" class="w-full mt-1 p-2 border rounded-md">
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Port -->
                    <div>
                        <label for="port" class="block text-sm font-medium text-gray-700">Port</label>
                        <input type="number" name="port" id="port" value="{{ $mailSettings['port'] ?? 587 }}"
                            required placeholder="587" class="w-full mt-1 p-2 border rounded-md">
                    </div>

                    <!-- Encryption Select -->
                    <div>
                        <label for="encryption" class="block text-sm font-medium text-gray-700">Encryption</label>
                        <select name="encryption" id="encryption" class="w-full mt-1 p-2 border rounded-md">
                            @foreach ($encryptions as $enc)
                                <option value="{{ $enc === 'null' ? '' : $enc }}"
                                    {{ ($mailSettings['encryption'] ?? 'tls') === $enc ? 'selected' : '' }}>
                                    {{ $enc === 'null' ? 'Off' : strtoupper($enc) }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Username -->
                    <div>
                        <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
                        <input type="text" name="username" id="username"
                            value="{{ $mailSettings['username'] ?? '' }}" required placeholder="mail@example.com"
                            class="w-full mt-1 p-2 border rounded-md">
                    </div>

                    <!-- Password -->
                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                        <input type="password" name="password" id="password"
                            @if (empty($mailSettings['id'])) required @endif placeholder="******"
                            class="w-full mt-1 p-2 border rounded-md">
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- From Address -->
                    <div>
                        <label for="from_address" class="block text-sm font-medium text-gray-700">From Address</label>
                        <input type="text" name="from_address" id="from_address"
                            value="{{ $mailSettings['from_address'] ?? '' }}" required placeholder="mail@example.com"
                            class="w-full mt-1 p-2 border rounded-md">
                    </div>

                    <!-- From Name -->
                    <div>
                        <label for="from_name" class="block text-sm font-medium text-gray-700">From Name</label>
                        <input type="text" name="from_name" id="from_name"
                            value="{{ $mailSettings['from_name'] ?? '' }}" required placeholder="Your Name"
                            class="w-full mt-1 p-2 border rounded-md">
                    </div>
                </div>

                <button type="submit" style="background-color: #0d99f2; color: white;" id="submitForm"
                    class="w-full bg-blue-600 text-black py-2 px-4 rounded-md hover:bg-blue-700 mt-6">
                    Save
                </button>
            </form>
        </div>
    </div>

    <script src="{{ URL::asset('assets/js/jquery-3.6.0.min.js') }}"></script>
    <script src="{{ URL::asset('assets/js/sweetalert2.min.js') }}"></script>
    <link rel="stylesheet" href="{{ URL::asset('assets/css/sweetalert2.min.css') }}">

    <script>
        var $langData = {
            'Success': `<?= $langData['Success'] ?? 'Success' ?>`,
            'saving data': `<?= $langData['saving data'] ?? 'Saving data...' ?>`,
            'ok': `<?= $langData['ok'] ?? 'OK' ?>`,
            'error': `<?= $langData['error'] ?? 'Error' ?>`
        };

        $(document).ready(function() {
            var mailSettings = @json($mailSettings);

            $('form').on('submit', function(e) {
                e.preventDefault();
                let formData = $(this).serializeArray();
                var submitButton = $('#submitForm');
                submitButton.prop('disabled', true).text('تحميل...');

                $.ajax({
                    url: "{{ route('mail-settings.save') }}",
                    method: "POST",
                    data: formData,
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: $langData['Success'],
                            text: response.message,
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => window.location.reload());
                    },
                    error: function(xhr) {
                        submitButton.prop('disabled', false);
                        let errorMessage = xhr.responseJSON?.message || 'An error occurred';
                        Swal.fire({
                            icon: 'error',
                            title: $langData['error'],
                            text: errorMessage
                        });
                    }
                });
            });
        });
    </script>
</x-filament::page>
