@php
    $heading = $this->record->title;
@endphp

<x-filament-panels::page>
    <div class="mb-6">
        <h2 class="text-2xl font-bold text-gray-900 dark:text-white">{{ __('Sub Topics') }} - {{ $heading }}</h2>
    </div>

    {{ $this->table }}
</x-filament-panels::page>
