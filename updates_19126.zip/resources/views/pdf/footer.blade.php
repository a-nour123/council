<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <style>
        body {
            margin: 0;
            padding: 5px 10px;
            font-family: 'DejaVu Sans', Arial, sans-serif;
            font-size: 12px;
            direction: rtl;
        }

        .footer-text {
            white-space: nowrap;
        }

        .footer-text br {
            display: none;
        }

        .footer-page {
            text-align: left;
            direction: ltr;
            white-space: nowrap;
        }

        table {
            width: 100%;
            table-layout: fixed;
            border-top: 1px solid #999;
            margin-top: 6px;
            padding-top: 6px;
        }

        td {
            white-space: nowrap;
        }

        td:last-child {
            text-align: left;
        }
    </style>
    <script>
        function substitutePageNumbers() {
            var vars = {};
            var query_strings_from_url = document.location.search.substring(1).split('&');

            for (var query_string in query_strings_from_url) {
                if (query_strings_from_url.hasOwnProperty(query_string)) {
                    var temp_var = query_strings_from_url[query_string].split('=', 2);
                    vars[temp_var[0]] = decodeURI(temp_var[1]);
                }
            }

            // Get page number
            var pageElement = document.getElementsByClassName('page');
            for (var j = 0; j < pageElement.length; ++j) {
                pageElement[j].textContent = vars['page'] || '1';
            }

            // Get total pages - try different variable names
            var toPageElement = document.getElementsByClassName('toPage');
            for (var j = 0; j < toPageElement.length; ++j) {
                toPageElement[j].textContent = vars['topage'] || vars['toPage'] || vars['sitepage'] || '0';
            }
        }
    </script>
</head>

<body onload="substitutePageNumbers()">
    @php
        use Alkoumi\LaravelHijriDate\Hijri;
        use Carbon\Carbon;
        use App\Models\Department;
        use App\Models\YearlyCalendar;
        use App\Models\Faculty;

        $endDateTime = Carbon::parse($session->actual_end_time);
        $startDateTime = Carbon::parse($session->start_time);

        $hijriEndDateTime = Hijri::DateIndicDigits('Y/m/d', $endDateTime->format('Y/m/d'));
        $higriDate = Hijri::DateIndicDigits('Y/m/d', $startDateTime->format('Y/m/d'));
        $dayName = Hijri::DateIndicDigits('l', $startDateTime->format('l'));
        $startDate = $startDateTime->format('Y/m/d');

        $parts = explode('_', $session->code);
        $department = Department::findOrFail($session->department_id);
        $faculty = Faculty::where('id', $department->faculty_id)->first();

        $yearCode = $parts[0];
        $departmentCode = $parts[1];
        $lastPart = $parts[2];

        $yearName = YearlyCalendar::where('code', $yearCode)->value('name');
        $departmentArName = Department::where('code', $departmentCode)->value('ar_name');
    @endphp

    <table>
        <tr>
            <td class="footer-text">
                محضر {{ $sessionOrder }} مجلس {{ $departmentName }} / {{ $facultyName }}<br>
                المنعقدة يوم {{ $dayName }} {{ $higriDate }} هـ الموافق {{ $startDate }} م
            </td>

            <td class="footer-page">
                صفحة <span class="page"></span> من <span class="toPage"></span>
            </td>
        </tr>
    </table>
</body>

</html>
