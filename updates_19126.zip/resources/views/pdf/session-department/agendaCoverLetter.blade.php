<!doctype html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>خطاب التغطية</title>

    <style>
        /* General Layout */
        @page {
            margin: 20mm 15mm 25mm 15mm;
        }

        * {
            box-sizing: border-box;
            font-family: 'DejaVu Sans', 'Arial', sans-serif;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'DejaVu Sans', 'Arial', sans-serif;
            direction: rtl;
            margin: 0;
            padding: 0;
            line-height: 1.8;
        }

        .cover-wrapper {
            max-width: 900px;
            padding: 20px;
            border: 2px solid #000;
            background-color: #fff;
            direction: rtl;
        }

        .main-content {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            direction: rtl;
            text-align: right;
        }

        .cover-wrapper {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .cover-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #000;
            padding: 1px 54px;
        }

        .arabic-section,
        .english-section {
            flex: 1;
            text-align: center;
        }

        .college-logo {
            height: 120px;
            margin: 0 30px;
        }

        .arabic-text,
        .english-text {
            font-size: 13px;
            font-weight: bold;
            margin: 0px;
            line-height: 20px;
            white-space: normal;
            word-wrap: break-word;
        }

        .arabic-text {
            color: black;
        }

        .english-text {
            color: black;
        }

        .centered-section {
            text-align: center;
        }

        .centered-text {
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0;
            color: black;
            white-space: normal;
            word-wrap: break-word;
        }

        .session-details {
            font-size: 16px;
            color: black;
            margin-top: 20px;
            white-space: normal;
            word-wrap: break-word;
        }

        .session-header {
            font-weight: bold;
            font-size: 18px;
            margin: 10px 0;
            white-space: normal;
            word-wrap: break-word;
        }

        .session-info {
            margin-top: 10px;
            line-height: 1.6;
            white-space: normal;
            word-wrap: break-word;
        }

        .college-message {
            text-align: center;
            margin: 30px 0;
        }

        .message-header {
            font-size: 20px;
            font-weight: bold;
            color: black;
            white-space: normal;
            word-wrap: break-word;
        }

        .message-body {
            font-size: 18px;
            line-height: 1.8;
            color: #c00505;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            table-layout: fixed;
        }

        table th,
        table td {
            padding: 8px;
            text-align: center;
            border: 1px solid #000;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        h3 {
            margin-top: 20px;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        h2 {
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        p {
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .text-primary {
            color: black;
        }

        .text-success {
            color: black;
        }

        .page-break {
            page-break-before: always;
        }

        .simple-table {
            width: 100%;
            border-collapse: collapse;
            font-family: 'DejaVu Sans', 'Arial', sans-serif;
            font-size: 14px;
            text-align: center;
            margin-top: 20px;
            table-layout: fixed;
        }

        .simple-table thead th {
            background-color: #f4f4f4;
            border: 1px solid #ddd;
            padding: 10px;
            font-weight: bold;
            white-space: normal;
            word-wrap: break-word;
        }

        .simple-table tbody td {
            padding: 8px;
            border: 1px solid #ddd;
            color: black;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .simple-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        ol {
            list-style-type: none;
            padding-left: 0;
            margin-left: 0;
        }

        ol li {
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
            margin-top: 16px;
        }

        .ql-align-center {
            text-align: center;
        }

        .ql-align-right {
            text-align: right;
        }

        .ql-align-justify {
            text-align: justify;
        }

        .hidden-table {
            border-collapse: collapse;
            width: 100%;
            border: none;
        }

        .hidden-table td {
            border: none !important;
        }
    </style>

</head>

<body>
    @php
        use Alkoumi\LaravelHijriDate\Hijri;
        use Carbon\Carbon;
        use App\Models\Department;
        use App\Models\YearlyCalendar;
        use App\Models\Faculty;

        $endDateTime = Carbon::parse($data['session']->actual_end_time);
        $startDateTime = Carbon::parse($data['session']->start_time);

        $hijriEndDateTime = Hijri::DateIndicDigits('Y/m/d', $endDateTime->format('Y/m/d'));
        $higriDate = Hijri::DateIndicDigits('Y/m/d', $startDateTime->format('Y/m/d'));
        $dayName = Hijri::DateIndicDigits('l', $startDateTime->format('l'));
        $startTime = $startDateTime->format('g:i A');
        $startTime = str_replace(['AM', 'PM'], ['ص', 'م'], $startTime);
        $startDate = $startDateTime->format('Y/m/d');
        $parts = explode('_', $data['session']->code);
        $department = Department::findOrFail($data['session']->department_id);
        $faculty = Faculty::where('id', $department->faculty_id)->first();

        $yearCode = $parts[0];
        $departmentCode = $parts[1];
        $lastPart = $parts[2];

        $yearName = YearlyCalendar::where('code', $yearCode)->value('name');
        $departmentArName = Department::where('code', $departmentCode)->value('ar_name');

        $newSessionCode = "{$yearName}_{$departmentArName}_{$lastPart}";
    @endphp
    <div class="container">
        <!-- Main Content Starts Here -->
        <div class="main-content">
            <!-- Header Section -->
            <div class="cover-header">
                <!-- Hidden Table Section -->
                <table class="hidden-table">
                    <tr>
                        <!-- Arabic Section (Left Side) -->
                        <td class="arabic-section">
                            <div class="arabic-text">المملكة العربية السعودية</div>
                            <div class="arabic-text">وزارة التعليم</div>
                            <div class="arabic-text">جامعة القصيم</div>
                            <div class="arabic-text">{{ $faculty->ar_name }}</div>
                            <div class="arabic-text">{{ $department->ar_name }}</div>
                        </td>

                        <!-- Logo Section (Center) -->
                        <td class="logo-section">
                            <img src="{{ public_path('assets/logo.png') }}" alt="College Logo" class="college-logo">
                        </td>

                        <!-- English Section (Right Side) -->
                        <td class="english-section">
                            <div class="english-text">Kingdom of Saudi Arabia</div>
                            <div class="english-text">Ministry of Education</div>
                            <div class="english-text">Qassim University</div>
                            <div class="english-text">{{ $faculty->en_name }}</div>
                            <div class="english-text">{{ $department->en_name }}</div>
                        </td>
                    </tr>
                </table>
            </div>

            <ol>
                @foreach ($data['topics'] as $mainTopic => $supTopics)
                    @foreach ($supTopics['details'] as $topic)
                        <li style="margin-top: 16px;">
                            {!! $topic['report_contents'] !!}
                        </li>
                    @endforeach
                @endforeach
            </ol>

        </div>
    </div>
</body>

</html>
