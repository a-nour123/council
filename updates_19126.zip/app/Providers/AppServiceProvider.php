<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use BezhanSalleh\FilamentLanguageSwitch\LanguageSwitch;
use BezhanSalleh\FilamentLanguageSwitch\Enums\Placement;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Crypt;
use App\Models\MailSetting;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        /**
         * -------------------------------------------------------
         * Filament Language Switch Configuration
         * -------------------------------------------------------
         */
        LanguageSwitch::configureUsing(function (LanguageSwitch $switch) {
            $switch
                ->locales(['ar'])
                ->labels([
                    'ar' => 'العربية',
                ])
                ->circular()
                ->visible(outsidePanels: true)
                ->outsidePanelPlacement(Placement::TopCenter);
        });

        /**
         * -------------------------------------------------------
         * Disable "Create Another" globally
         * -------------------------------------------------------
         */
        CreateRecord::disableCreateAnother();

        CreateAction::configureUsing(
            fn(CreateAction $action) => $action->createAnother(false)
        );

        /**
         * -------------------------------------------------------
         * Load Mail Settings Dynamically from Database
         * -------------------------------------------------------
         */
        $settings = MailSetting::first();

        if ($settings) {
            Config::set('mail.mailers.smtp.host', $settings->host ?? '');
            Config::set('mail.mailers.smtp.port', $settings->port ?? 587);
            Config::set('mail.mailers.smtp.username', $settings->username ?? '');
            Config::set('mail.mailers.smtp.password', $settings->password ? Crypt::decrypt($settings->password) : '');
            Config::set('mail.mailers.smtp.encryption', $settings->encryption ?? null);

            Config::set('mail.from.address', $settings->from_address ?? '');
            Config::set('mail.from.name', $settings->from_name ?? '');
        }
    }
}
