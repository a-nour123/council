<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class SessionInvitationNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $sessionDepartmentName;
    protected $sessionCode;
    protected $url;

    public function __construct($sessionDepartmentName, $sessionCode, $url)
    {
        $this->sessionDepartmentName = $sessionDepartmentName;
        $this->sessionCode = $sessionCode;
        $this->url = $url;
    }

    public function via($notifiable)
    {
        return ['mail', 'database']; // store in database & send email
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('لقد تمت دعوتك لحضور جلسة مجلس قسم')
            ->greeting('السلام عليكم')
            ->line('قسم: ' . $this->sessionDepartmentName . ' جلسة رقم: ' . $this->sessionCode)
            ->action('عرض الجلسة', $this->url)
            ->line('شكراً لاستخدامك نظامنا!');
    }

    public function toArray($notifiable)
    {
        return [
            'title' => 'لقد تمت دعوتك لحضور جلسة مجلس قسم',
            'body' => 'قسم: ' . $this->sessionDepartmentName . ' جلسة رقم: ' . $this->sessionCode,
            'url' => $this->url,
        ];
    }
}
