<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MailSettingResource\Pages;
use App\Models\MailSetting;
use App\Models\User;
use Filament\Resources\Resource;

class MailSettingResource extends Resource
{
    protected static ?string $model = MailSetting::class;
    protected static ?string $slug = 'mail-settings';

    protected static ?string $navigationIcon = 'heroicon-o-envelope';

    public static function canViewAny(): bool
    {
        return auth()->user()->can('mailConfigration', arguments: User::class);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ManageMailSettings::route('/'),
        ];
    }

    public static function getBreadcrumb(): string
    {
        return '';
    }

    public static function getPluralLabel(): ?string
    {
        return __('Mail Settings');
    }
}
