<?php

namespace App\Filament\Resources\MailSettingResource\Pages;

use App\Filament\Resources\MailSettingResource;
use App\Models\MailSetting;
use Filament\Resources\Pages\Page;
use Illuminate\Contracts\Support\Htmlable;

class ManageMailSettings extends Page
{
    protected static string $resource = MailSettingResource::class;
    protected static string $view = 'filament.resources.mail-settings.form';

    public $mailSettings;

    public function mount()
    {
        $this->mailSettings = MailSetting::first();
    }

    public function getTitle(): string|Htmlable
    {
        return __('Mail Settings');
    }

    public function getBreadcrumb(): ?string
    {
        return null;
    }
}
