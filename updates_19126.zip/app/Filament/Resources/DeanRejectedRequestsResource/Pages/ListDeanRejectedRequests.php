<?php

namespace App\Filament\Resources\DeanRejectedRequestsResource\Pages;

use App\Filament\Resources\DeanRejectedRequestsResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListDeanRejectedRequests extends ListRecords
{
    protected static string $resource = DeanRejectedRequestsResource::class;

    protected function getHeaderActions(): array
    {
        return [
            // Actions\CreateAction::make(),
        ];
    }
}
