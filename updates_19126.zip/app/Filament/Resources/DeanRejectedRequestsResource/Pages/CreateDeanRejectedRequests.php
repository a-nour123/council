<?php

namespace App\Filament\Resources\DeanRejectedRequestsResource\Pages;

use App\Filament\Resources\DeanRejectedRequestsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDeanRejectedRequests extends CreateRecord
{
    protected static string $resource = DeanRejectedRequestsResource::class;
}
