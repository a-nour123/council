<?php

namespace App\Filament\Resources\DeanRejectedRequestsResource\Pages;

use App\Filament\Resources\DeanRejectedRequestsResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditDeanRejectedRequests extends EditRecord
{
    protected static string $resource = DeanRejectedRequestsResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
