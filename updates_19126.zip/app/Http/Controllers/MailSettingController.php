<?php

namespace App\Http\Controllers;

use App\Models\MailSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

class MailSettingController extends Controller
{
    public function saveSettings(Request $request)
    {
        // Validate request based on your MailSetting model fields
        $request->validate([
            'id'           => 'nullable|exists:mail_settings,id',
            'mailer'       => 'required|string|in:smtp,sendmail,log',
            'host'         => 'required|string',
            'port'         => 'required|integer',
            'username'     => 'nullable|string',
            'password'     => [MailSetting::first() ? 'nullable' : 'required'],
            'encryption'   => 'nullable|in:ssl,tls,starttls',
            'from_address' => 'required|email',
            'from_name'    => 'required|string',
        ]);

        $mailSetting = MailSetting::updateOrCreate(
            ['id' => $request->id],
            [
                'mailer'       => $request->mailer,
                'host'         => $request->host,
                'port'         => $request->port,
                'username'     => $request->username,
                'encryption'   => $request->encryption,
                'from_address' => $request->from_address,
                'from_name'    => $request->from_name,
            ]
        );

        // Encrypt password ONLY if user entered a new one
        if ($request->filled('password')) {
            $mailSetting->update([
                'password' => Crypt::encrypt($request->password)
            ]);
        }

        return response()->json(['message' => 'تم حفظ الإعدادات بنجاح']);
    }
}
