<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MailSetting extends Model
{
    use HasFactory;
    protected $fillable = [
        'mailer', // smtp, exchange
        'host', // smtp.gmail.com
        'port', // 587
        'username', // mail@mail.com
        'password',
        'encryption', // null, ssl, tls, starttls
        'from_address', // mail@mail.com
        'from_name', // Name of From
    ];
}
