<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AcadimicRank extends Model
{
    use HasFactory;
    protected $fillable = ['name', 'ar_name'];
    public $timestamps = false;
    public function users(): HasMany
    {
        return $this->HasMany(User::class);
    }
}
