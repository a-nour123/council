<!doctype html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>محضر جلسة القسم</title>

    <style>
        /* General Layout */
        @page {
            margin: 20mm 15mm;
        }

        * {
            box-sizing: border-box;
            /* font-family: 'DejaVu Sans', sans-serif; */
            font-family: 'AlMohanad', sans-serif;
            margin: 0;
            padding: 0;
        }

        body {
            /* font-family: 'DejaVu Sans', 'Arial', sans-serif; */
            font-family: 'AlMohanad', sans-serif;
            direction: rtl;
            margin: 0;
            padding: 0;
            line-height: 1.8;
        }

        .cover-wrapper {
            max-width: 900px;
            padding: 20px;
            border: 2px solid #000;
            background-color: #fff;
            direction: rtl;
            page-break-after: always;
        }

        .cover-wrapper-footer {
            page-break-inside: avoid;
            page-break-before: always;
            max-height: 100vh;
            max-width: 900px;
            padding: 20px;
            border: 2px solid #000;
            background-color: #fff;
            direction: rtl;
        }


        .main-content {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            direction: rtl;
            text-align: right;
        }

        .cover-wrapper {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .cover-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #000;
            padding: 1px 54px;
        }

        .arabic-section,
        .english-section {
            flex: 1;
            text-align: center;
        }

        .college-logo {
            height: 120px;
            margin: 0 30px;
        }

        /* Arabic & English Text Styling */
        .arabic-text,
        .english-text {
            font-size: 13px;
            font-weight: bold;
            margin: 0px;
            line-height: 20px;
            white-space: normal;
            word-wrap: break-word;
        }

        .arabic-text {
            color: black;
        }

        .english-text {
            color: black;
        }

        /* Centered Text Section */
        .centered-section {
            text-align: center;
        }

        .centered-text {
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0;
            color: black;
            white-space: normal;
            word-wrap: break-word;
        }

        .session-details {
            font-size: 16px;
            color: black;
            margin-top: 20px;
            white-space: normal;
            word-wrap: break-word;
        }

        .session-header {
            font-weight: bold;
            font-size: 18px;
            margin: 10px 0;
            white-space: normal;
            word-wrap: break-word;
        }

        .session-info {
            margin-top: 10px;
            line-height: 1.6;
            white-space: normal;
            word-wrap: break-word;
        }

        /* College Message Section */
        .college-message {
            text-align: center;
            margin: 30px 0;
        }

        .message-header {
            font-size: 20px;
            font-weight: bold;
            color: black;
            white-space: normal;
            word-wrap: break-word;
        }

        .message-body {
            font-size: 18px;
            line-height: 1.8;
            color: #c00505;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            table-layout: fixed;
        }

        table th,
        table td {
            padding: 8px;
            text-align: center;
            border: 1px solid #000;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        h3 {
            margin-top: 20px;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        h2 {
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        p {
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .text-primary {
            color: black;
        }

        .text-success {
            color: black;
        }

        /* Ensure no page break within content */
        .page-break {
            page-break-before: always;
        }

        /* Table layout */
        .simple-table {
            width: 100%;
            border-collapse: collapse;
            /* font-family: 'DejaVu Sans', 'Arial', sans-serif; */
            font-family: 'AlMohanad', sans-serif;
            font-size: 14px;
            text-align: center;
            margin-top: 20px;
            table-layout: fixed;
        }

        /* Header style */
        .simple-table thead th {
            background-color: #f4f4f4;
            border: 1px solid #ddd;
            padding: 10px;
            font-weight: bold;
            white-space: normal;
            word-wrap: break-word;
        }

        /* Body cells style */
        .simple-table tbody td {
            padding: 8px;
            border: 1px solid #ddd;
            color: black;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        /* Alternating row background color */
        .simple-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        ol {
            list-style-type: none;
            padding-left: 0;
            margin-left: 0;
        }

        ol li {
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .bordered-div {
            border: 2px solid #000;
            padding: 20px;
            margin: 20px 0;
            width: fit-content;
            text-align: center;
            border-radius: 8px;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .ql-align-center {
            text-align: center;
        }

        .ql-align-right {
            text-align: right;
        }

        .ql-align-justify {
            text-align: justify;
        }

        .signature-cell img {
            max-width: 100px;
            height: auto;
        }

        .topics-table th:first-child,
        .topics-table td:first-child {
            width: 18%;
            white-space: nowrap;
        }
    </style>

</head>

<body>
    @php
        use Alkoumi\LaravelHijriDate\Hijri;
        use Carbon\Carbon;
        use App\Models\Department;
        use App\Models\YearlyCalendar;
        use App\Models\Faculty;

        $endDateTime = Carbon::parse($data['session']->actual_end_time);
        $startDateTime = Carbon::parse($data['session']->start_time);

        $hijriEndDateTime = Hijri::DateIndicDigits('Y/m/d', $endDateTime->format('Y/m/d'));
        $higriDate = Hijri::DateIndicDigits('Y/m/d', $startDateTime->format('Y/m/d'));
        $dayName = Hijri::DateIndicDigits('l', $startDateTime->format('l'));
        $startTime = $startDateTime->format('g:i A'); // 12-hour format with minutes and AM/PM
        $startTime = str_replace(['AM', 'PM'], ['ص', 'م'], $startTime);
        $startDate = $startDateTime->format('Y/m/d');
        // Split the code into parts using "_"
        $parts = explode('_', $data['session']->code);
        $department = Department::findOrFail($data['session']->department_id);
        $faculty = Faculty::where('id', $department->faculty_id)->first();
        // dd(['$department' => $department['ar_name'], '$faculty' => $faculty['ar_name']]);
        $departmentMessage = $department->message;

        // Assign the parts to variables
        $yearCode = $parts[0]; // Before the first "_"
        $departmentCode = $parts[1]; // Between the first and second "_"
        $lastPart = $parts[2]; // After the second "_"

        $yearName = YearlyCalendar::where('code', $yearCode)->value('name');
        $departmentArName = Department::where('code', $departmentCode)->value('ar_name');

        $newSessionCode = "{$yearName}_{$departmentArName}_{$lastPart}";
    @endphp
    <div class="container">
        <!-- Cover Page -->
        <div class="cover-wrapper" style="margin:100px auto">
            <!-- Header Section -->
            <div class="cover-header" style="margin-bottom:100px">
                <!-- Hidden Table Section -->
                <table class="hidden-table" style="border-collapse: collapse; width: 100%; border: none;">
                    <tr>
                        <!-- Arabic Section (Left Side) -->
                        <td class="arabic-section" style="border: none;">
                            <div class="arabic-text">المملكة العربية السعودية</div>
                            <div class="arabic-text">وزارة التعليم</div>
                            <div class="arabic-text">جامعة القصيم</div>
                            <div class="arabic-text">{{ $faculty->ar_name }}</div>
                            <div class="arabic-text">{{ $department->ar_name }}</div>
                        </td>

                        <!-- Logo Section (Center) -->
                        <td class="logo-section" style="border: none;">
                            <img src="{{ public_path('assets/logo.png') }}" alt="College Logo" class="college-logo">
                        </td>

                        <!-- English Section (Right Side) -->
                        <td class="english-section" style="border: none;">
                            <div class="english-text">Kingdom of Saudi Arabia</div>
                            <div class="english-text">Ministry of Education</div>
                            <div class="english-text">Qassim University</div>
                            <div class="english-text">{{ $faculty->en_name }}</div>
                            <div class="english-text">{{ $department->en_name }}</div>
                        </td>
                    </tr>
                </table>
            </div>



            <!-- Centered Text Section -->
            <div class="centered-section" style="margin:20px auto 0px">
                <div class="centered-text">
                    بسم الله الرحمن الرحيم
                </div>

                <div class="session-details bordered-div" style="margin-top: 80px">
                    <div class="session-header">
                        {{-- مجلس {{ $data['session']->department->faculty->ar_name }} /
                        {{ $data['session']->department->ar_name }} --}}
                         مجلس {{ $data['session']->department->ar_name }} / {{ $data['session']->department->faculty->ar_name }}
                    </div>
                    <span style="font-size: 18px">محضر</span>
                    <div class="session-info">
                        {{ $data['sessionOrder'] }} للعام الجامعى {{ $yearName }}<br>
                        المنعقدة يوم {{ $dayName }} {{ $higriDate }} هـ الموافق {{ $startDate }} م
                    </div>
                </div>
            </div>

            <!-- College Message Section -->
            <div class="college-message" style="margin:100px auto 100px">
                <div class="message-header">رسالة القسم</div>
                <div class="message-body bordered-div" style="margin-bottom: 300px; color: #000;">
                    {{-- تعمل الكلية على إكساب خريجيها المعارف والمهارات الشخصية العلمية والمهنية التي تؤهلهم للالتحاق
                    بالدراسات العليا أو بسوق العمل بكفاءة، وتشجع الكلية البحث العلمي والنشر الدولي للمساهمة في
                    التقدم في العلوم الأساسية وتطبيقاتها، وتوظف نتائجه لخدمة المجتمع وحل مشكلاته. وتقوم الكلية بأداء
                    رسالتها في إطار من العدالة والمساواة يضمن عدم التمييز بين أعضاء هيئة التدريس والعاملين والطلاب. --}}
                    {!! $departmentMessage !!}
                </div>
            </div>
        </div>

        <!-- Main Content Starts Here -->
        <div class="main-content" style="margin-bottom:10px ">
            <!-- Header Section -->
            <div class="cover-header">
                <!-- Hidden Table Section -->
                <table class="hidden-table" style="border-collapse: collapse; width: 100%; border: none;">
                    <tr>
                        <!-- Arabic Section (Left Side) -->
                        <td class="arabic-section" style="border: none;">
                            <div class="arabic-text">المملكة العربية السعودية</div>
                            <div class="arabic-text">وزارة التعليم</div>
                            <div class="arabic-text">جامعة القصيم</div>
                            <div class="arabic-text">{{ $faculty->ar_name }}</div>
                            <div class="arabic-text">{{ $department->ar_name }}</div>
                        </td>

                        <!-- Logo Section (Center) -->
                        <td class="logo-section" style="border: none;">
                            <img src="{{ public_path('assets/logo.png') }}" alt="College Logo" class="college-logo">
                        </td>

                        <!-- English Section (Right Side) -->
                        <td class="english-section" style="border: none;">
                            <div class="english-text">Kingdom of Saudi Arabia</div>
                            <div class="english-text">Ministry of Education</div>
                            <div class="english-text">Qassim University</div>
                            <div class="english-text">{{ $faculty->en_name }}</div>
                            <div class="english-text">{{ $department->en_name }}</div>
                        </td>
                    </tr>
                </table>
            </div>


            <h2 style="text-align: center; margin-bottom:15px;margin-top: 30px;" class="mb-4">محضر
                {{ $data['sessionOrder'] }}
                {{-- للعام الجامعي {{ $yearName }} --}}
                لمجلس {{ $data['session']->department->ar_name }} ب{{ $data['session']->department->faculty->ar_name }}</h2>

            <p style="text-align: center;" class="mb-3">المنعقدة يوم {{ $dayName }} {{ $higriDate }} هـ
                الموافق {{ $startDate }} م </p>
            <p style="text-align: center;" class="mb-4">الحمد لله والصلاة والسلام على نبينا محمد وعلى آله وصحبه أجمعين
                أما بعد .</p>
            <p style="text-align: center;" class="mb-5">فقد انعقد مجلس القسم برئاسة رئيس القسم
                {{ $data['session']->responsible->name }} في
                {{ $data['session']->place }} في تمام الساعة {{ $startTime }} وبعضوية كل من:</p>

            <h3 style="text-align: center;" class="text-primary mb-3">أعضاء مجلس القسم</h3>
            <table class="simple-table">
                <thead>
                    <tr>
                        <th scope="col">الاسم</th>
                        <th scope="col">المنصب</th>
                        <th scope="col">الحضور</th>
                    </tr>
                </thead>
                <tbody>
                    {{-- @foreach ($data['sessionAttendance'] as $attendance)
                        <tr>
                            <td>{{ $attendance->userName }}</td>
                            <td>{{ $attendance->position }}</td>
                            <td>
                                @if ($attendance->attendance == 1)
                                    <span>حاضر</span>
                                @else
                                    <span>غائب</span>
                                @endif
                            </td>
                        </tr>
                    @endforeach --}}
                    @foreach ($data['members']['members'] as $member)
                        <tr>
                            <td>{{ $member['name'] }}</td>
                            <td>{{ $member['title'] }}</td>
                            <td>{{ $member['attendance'] }}</td>
                        </tr>
                    @endforeach
                    <tr>
                        <td colspan="2" style="text-align: right; font-weight: bold;">نسبة الحضور:</td>
                        <td id="attendance-percentage" style="font-weight: bold;">
                            {{ $data['attendance-percentage'] }}%
                        </td>
                    </tr>
                </tbody>
            </table>


            <h2 style="text-align: center;margin-bottom:9px;margin-top: 16px;">مناقشة جدول الأعمال</h2>
            <p style="text-align: center;">وتم استعراض جدول الأعمال ومناقشة ما ورد فيه واتخذ مجلس القسم القرارات
                والتوصيات وفق ما يلي :</p>

            <div class="cover-header" style="page-break-before: always;">
                <!-- Hidden Table Section -->
                <table class="hidden-table" style="border-collapse: collapse; width: 100%; border: none;">
                    <tr>
                        <!-- Arabic Section (Left Side) -->
                        <td class="arabic-section" style="border: none;">
                            <div class="arabic-text">المملكة العربية السعودية</div>
                            <div class="arabic-text">وزارة التعليم</div>
                            <div class="arabic-text">جامعة القصيم</div>
                            <div class="arabic-text">{{ $faculty->ar_name }}</div>
                            <div class="arabic-text">{{ $department->ar_name }}</div>
                        </td>

                        <!-- Logo Section (Center) -->
                        <td class="logo-section" style="border: none;">
                            <img src="{{ public_path('assets/logo.png') }}" alt="College Logo" class="college-logo">
                        </td>

                        <!-- English Section (Right Side) -->
                        <td class="english-section" style="border: none;">
                            <div class="english-text">Kingdom of Saudi Arabia</div>
                            <div class="english-text">Ministry of Education</div>
                            <div class="english-text">Qassim University</div>
                            <div class="english-text">{{ $faculty->en_name }}</div>
                            <div class="english-text">{{ $department->en_name }}</div>
                        </td>
                    </tr>
                </table>
            </div>

            <table class="simple-table topics-table">
                <thead>
                    <tr>
                        <th style="width: 15%;">ترتيب الموضوع</th>
                        <th style="width: 85%;">عنوان الموضوع</th>
                    </tr>
                </thead>
                <tbody>
                    @php $i = 1; @endphp
                    @foreach ($data['topics'] as $mainTopic => $supTopics)
                        <tr>
                            <td colspan="2" class="text-center"><strong>{{ $mainTopic }}</strong></td>
                        </tr>
                        @foreach ($supTopics['details'] as $topic)
                            <tr>
                                <td>الموضوع {{ $data['arabicOrder'][$i] }}</td>
                                <td>{!! strip_tags($topic['topic_title']) !!}</td>
                            </tr>
                            @php $i++; @endphp
                        @endforeach
                    @endforeach
                </tbody>
            </table>

            @php $i = 1; @endphp
            @foreach ($data['topics'] as $mainTopic => $supTopics)
                @foreach ($supTopics['details'] as $topic)
                    <div class="topic-page" style="page-break-before: always;"> <!-- Page break for each subtopic -->
                        <!-- Header Cover for Each Subtopic -->
                        <div class="cover-header" style="margin-bottom:20px; ">
                            <!-- Hidden Table Section -->
                            <table class="hidden-table" style="border-collapse: collapse; width: 100%; border: none;">
                                <tr>
                                    <!-- Arabic Section (Left Side) -->
                                    <td class="arabic-section" style="border: none;">
                                        <div class="arabic-text">المملكة العربية السعودية</div>
                                        <div class="arabic-text">وزارة التعليم</div>
                                        <div class="arabic-text">جامعة القصيم</div>
                                        <div class="arabic-text">{{ $faculty->ar_name }}</div>
                                        <div class="arabic-text">{{ $department->ar_name }}</div>
                                    </td>

                                    <!-- Logo Section (Center) -->
                                    <td class="logo-section" style="border: none;">
                                        <img src="{{ public_path('assets/logo.png') }}" alt="College Logo"
                                            class="college-logo">
                                    </td>

                                    <!-- English Section (Right Side) -->
                                    <td class="english-section" style="border: none;">
                                        <div class="english-text">Kingdom of Saudi Arabia</div>
                                        <div class="english-text">Ministry of Education</div>
                                        <div class="english-text">Qassim University</div>
                                        <div class="english-text">{{ $faculty->en_name }}</div>
                                        <div class="english-text">{{ $department->en_name }}</div>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <!-- Main Topic Title -->
                        <center>
                            <div
                                style="background-color: #f5f5f5; border-bottom: 1px solid; padding: 10px; border-radius: 5px; position: relative; text-align: center;">
                                <h3 style="margin: 0; font-weight: bold; position: relative; z-index: 1;">
                                    {{ $mainTopic }}
                                </h3>
                            </div>
                        </center>

                        <!-- Subtopic Title -->
                        <h3 style="margin-top:24px ">الموضوع {{ $data['arabicOrder'][$i] }} : {!! strip_tags($topic['topic_title']) !!}
                        </h3>

                        <!-- Subtopic Content -->
                        <ol>
                            <li style="margin-top: 16px;">
                                {!! $topic['report_contents'] !!}
                            </li>
                        </ol>
                        <hr style="border: none; border-top: 2px solid #ccc; width: 100%; margin: 15px auto;">

                        @php $i++; @endphp
                    </div>
                @endforeach
            @endforeach



            @if ($data['decisionApproval'] == 1)
                <h3 style="text-align: center;" class="text-success mt-4">تم اعتماد المحضر
                    بتاريخ:<span>{{ $hijriEndDateTime }}</span>
                </h3>
            @else
                <h3 style="text-align: center;" class="text-success mt-4">تم رفض اعتماد المحضر
                    بتاريخ:<span>{{ $hijriEndDateTime }}</span>
                </h3>
            @endif
            <h3 style="text-align: center;" class="text-success mt-4">
                معد المحضر:
                {{ $data['session']->createdBy->ar_name }}
            </h3>
            @if (!empty($data['session']->createdBy->signature))
                <div class="signature-cell" style="text-align: center;">
                    <img src="{{ storage_path('app/public/' . $data['session']->createdBy->signature) }}"
                        alt="توقيع امين المجلس" style="margin: auto;text-align: center;height: auto;max-width: 10%;">
                </div>
            @else
                <div class="signature-cell" style="text-align: center;">
                    <p>لا يوجد توقيع</p>
                </div>
            @endif
        </div>

        <div class="cover-wrapper-footer"
            style="margin: 20px auto; border: none !important; page-break-inside: avoid;">
            <!-- Header Section -->
            <div class="cover-header">
                <table class="hidden-table" style="border-collapse: collapse; width: 100%; border: none;">
                    <tr>
                        <!-- Arabic Section (Left Side) -->
                        <td class="arabic-section" style="border: none;">
                            <div class="arabic-text">المملكة العربية السعودية</div>
                            <div class="arabic-text">وزارة التعليم</div>
                            <div class="arabic-text">جامعة القصيم</div>
                            <div class="arabic-text">{{ $faculty->ar_name }}</div>
                            <div class="arabic-text">{{ $department->ar_name }}</div>
                        </td>

                        <!-- Logo Section (Center) -->
                        <td class="logo-section" style="border: none;">
                            <img src="{{ public_path('assets/logo.png') }}" alt="College Logo" class="college-logo">
                        </td>

                        <!-- English Section (Right Side) -->
                        <td class="english-section" style="border: none;">
                            <div class="english-text">Kingdom of Saudi Arabia</div>
                            <div class="english-text">Ministry of Education</div>
                            <div class="english-text">Qassim University</div>
                            <div class="english-text">{{ $faculty->en_name }}</div>
                            <div class="english-text">{{ $department->en_name }}</div>
                        </td>
                    </tr>
                </table>
            </div>

            <h2 style="text-align: center; margin-bottom:15px;margin-top: 30px;" class="mb-4">توثيق حضور
                {{ $data['sessionOrder'] }}
                لمجلس {{ $data['session']->department->ar_name }} ب{{ $data['session']->department->faculty->ar_name }}</h2>

            <p style="text-align: center;" class="mb-3">المنعقدة يوم {{ $dayName }} {{ $higriDate }} هـ
                الموافق {{ $startDate }} م </p>

            <h3 style="text-align: center;" class="text-primary mb-3">أعضاء مجلس القسم</h3>

            @if ($data['members']['members'])
                <table class="simple-table">
                    <thead>
                        <tr>
                            <th scope="col">الاسم</th>
                            <th scope="col">المنصب</th>
                            <th scope="col">الحضور</th>
                            <th>التوقيع</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data['members']['members'] as $member)
                            <tr>
                                <td>{{ $member['name'] }}</td>
                                <td>{{ $member['title'] }}</td>
                                <td>{{ $member['attendance'] }}</td>
                                <td class="signature-cell" style="text-align: center;">
                                    @if ($member['signature'] === 'غائب')
                                        {{ $member['signature'] }}
                                    @elseif ($member['signature'] === 'رفض المستخدم التوقيع')
                                        {{ $member['signature'] }}
                                    @elseif(empty($member['signature']))
                                        لا يوجد توقيع للعضو
                                    @else
                                        @php
                                            $signaturePath = storage_path('app/public/' . $member['signature']);
                                        @endphp
                                        @if (file_exists($signaturePath) && is_file($signaturePath))
                                            <img src="{{ $signaturePath }}" alt="Signature"
                                                style="width: 100px;margin: auto; max-width: 100%; height: auto;">
                                        @else
                                            لا يوجد توقيع للعضو
                                        @endif
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        <tr>
                            <td colspan="3" style="text-align: right; font-weight: bold;">نسبة الحضور:</td>
                            <td id="attendance-percentage2" style="font-weight: bold;">
                                {{ $data['attendance-percentage'] }}%
                            </td>
                        </tr>
                    </tbody>
                </table>
            @endif

            @if ($data['members']['invitedMembers'])
                <h3 style="text-align: center;" class="text-primary mb-3">أعضاء المجلس المدعوون</h3>
                <table class="simple-table">
                    <thead>
                        <tr>
                            <th scope="col">الاسم</th>
                            <th scope="col">المنصب</th>
                            <th scope="col">الحضور</th>
                            <th>التوقيع</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data['members']['invitedMembers'] as $invitedMember)
                            <tr>
                                <td>{{ $invitedMember['name'] }}</td>
                                <td>{{ $invitedMember['title'] }}</td>
                                <td>{{ $invitedMember['attendance'] }}</td>
                                <td class="signature-cell" style="text-align: center;">
                                    @if ($invitedMember['signature'] === 'غائب')
                                        {{ $invitedMember['signature'] }}
                                    @elseif(empty($invitedMember['signature']))
                                        لا يوجد توقيع
                                    @else
                                        @php
                                            $signaturePath = storage_path('app/public/' . $invitedMember['signature']);
                                        @endphp
                                        @if (file_exists($signaturePath) && is_file($signaturePath))
                                            <img src="{{ $signaturePath }}" alt="Signature"
                                                style="width: 100px;margin: auto; max-width: 100%; height: auto;">
                                        @else
                                            لا يوجد توقيع
                                        @endif
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @endif
        </div>

    </div>
</body>

</html>
